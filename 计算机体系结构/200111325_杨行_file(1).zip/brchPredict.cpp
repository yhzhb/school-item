#include <iostream>
#include <fstream>
#include <cassert>
#include <stdarg.h>
#include <cstdlib>
#include <cstring>
#include "pin.H"

using namespace std;

typedef unsigned char       UINT8;
typedef unsigned short      UINT16;
typedef unsigned int        UINT32;
typedef unsigned long int   UINT64;
typedef unsigned __int128   UINT128;



ofstream OutFile;

// ��val�ض�, ʹ����ȱ��bits
#define truncate(val, bits) ((val) & ((1 << (bits)) - 1))

static UINT64 takenCorrect = 0;
static UINT64 takenIncorrect = 0;
static UINT64 notTakenCorrect = 0;
static UINT64 notTakenIncorrect = 0;

// ���ͼ����� (N < 64)
class SaturatingCnt
{
    size_t m_wid;
    UINT8 m_val;
    const UINT8 m_init_val;

    public:
        SaturatingCnt(size_t width = 2) : m_init_val((1 << width) / 2)
        {
            m_wid = width;
            m_val = m_init_val;
        }

        void increase() { if (m_val < (1 << m_wid) - 1) m_val++; }
        void decrease() { if (m_val > 0) m_val--; }

        void set_weak(){m_val = (1 << m_wid) - 1; }
        void set_zero(){m_val = 0;}
        void reset() { m_val = m_init_val; }
        UINT8 getVal() { return m_val; }

        bool half_(){return (m_val == (1<<m_wid)/2);}
        bool half_sub_one(){return(m_val == (1 << m_wid)/2 - 1);}
        bool isTaken() { return (m_val > (1 << m_wid)/2 - 1); }
};

// ��λ�Ĵ��� (N < 128)
class ShiftReg
{
    size_t m_wid;
    UINT128 m_val;

    public:
        ShiftReg(size_t width) : m_wid(width), m_val(0) {}

        bool shiftIn(bool b)
        {
            bool ret = !!(m_val & (1 << (m_wid - 1)));
            m_val <<= 1;
            m_val |= b;
            m_val &= (1 << m_wid) - 1;
            return ret;
        }

        UINT128 getVal() { return m_val; }
};

// Hash functions
inline UINT128 f_xor(UINT128 a, UINT128 b) { return a ^ b; }
inline UINT128 f_xor1(UINT128 a, UINT128 b) { return ~a ^ ~b; }
inline UINT128 f_xnor(UINT128 a, UINT128 b) { return ~(a ^ ~b) ; }








//inline UINT128 f_xnor(UINT128 a, UINT128 b) { return a^b^(rand()%2) ; }
inline UINT128 Hash1(UINT128 a,UINT128 b){ return (a>>12)^a^truncate(b,12); }
//inline UINT128 Hash2(UINT128 a,UINT128 b){return a^truncate(b,12)^(2*(truncate(b,12-1)));}


// Base class of all predictors
class BranchPredictor
{
    public:
        BranchPredictor() {}
        virtual ~BranchPredictor() {}
        virtual bool predict(ADDRINT addr) { return false; };
        virtual void update(bool takenActually, bool takenPredicted, ADDRINT addr) {};
        virtual void reset_ctr(ADDRINT addr){};
        virtual UINT128 get_ghr(){return 0;};
        virtual UINT128 get_tag(ADDRINT addr){return 0;};
};

BranchPredictor* BP;

int tag_size = 1;

/* ===================================================================== */
/* BHT-based branch predictor                                            */
/* ===================================================================== */
class BHTPredictor: public BranchPredictor
{
    size_t m_entries_log;
    SaturatingCnt* m_scnt;              // BHT
    allocator<SaturatingCnt> m_alloc;

   //int cnt_=50 ;
   //ADDRINT cnt=0;

    public:
        // Constructor
        // param:   entry_num_log:  BHT行数的对数
        //          scnt_width:     饱和计数器的位数, 默认值为2
        BHTPredictor(size_t entry_num_log, size_t scnt_width = 2)
        {
            m_entries_log = entry_num_log;

            m_scnt = m_alloc.allocate(1 << entry_num_log);      // Allocate memory for BHT
            for (int i = 0; i < (1 << entry_num_log); i++)
                m_alloc.construct(m_scnt + i, scnt_width);      // Call constructor of SaturatingCnt
        }

        // Destructor
        ~BHTPredictor()
        {
            for (int i = 0; i < (1 << m_entries_log); i++)
                m_alloc.destroy(m_scnt + i);

            m_alloc.deallocate(m_scnt, 1 << m_entries_log);
        }

        BOOL predict(ADDRINT addr)
        {
            // TODO: Produce prediction according to BHT
            ADDRINT tag = truncate(addr,m_entries_log);

           // if(cnt_>0){
           // printf("%d<<.",m_scnt[tag].getVal());
           // printf("%ld\n",tag);
           // cnt_--;
           // }
              
              //if(cnt==0){
                //    cnt = tag;
             // }
             // if(tag==cnt){
            //  printf("********\n");
             // printf("tag:%ld,val:%d,%d\n",tag,m_scnt[tag].getVal(),m_scnt[tag].isTaken());
            //  }
            
              return m_scnt[tag].isTaken();

        }

        void update(BOOL takenActually, BOOL takenPredicted, ADDRINT addr)
        {
            // TODO: Update BHT according to branch results and prediction
            ADDRINT tag = truncate(addr,m_entries_log);

            UINT8 val = m_scnt[tag].getVal();
           // printf("long:%ld,addr:%ld,tag:%ld,val:%d\n",(ADDRINT)m_entries_log,addr,tag,val);
           if(takenActually){ //发生跳转
              // if(tag==cnt){
              // printf("increase\n");
             // }
               m_scnt[tag].increase();
               if(val == 1){
                      m_scnt[tag].increase();
               }
            }else {
            //  if(tag==cnt){
             // printf("decrease\n");
             // }
              m_scnt[tag].decrease();
              if(val == 2){
                    m_scnt[tag].decrease();
              }
            }


        }
};

/* ===================================================================== */
/* Global-history-based branch predictor                                 */
/* ===================================================================== */
template<UINT128 (*hash)(UINT128 addr, UINT128 history)>
class GlobalHistoryPredictor: public BranchPredictor
{
    ShiftReg* m_ghr;                   // GHR
    SaturatingCnt* m_scnt;              // PHT�еķ�֧��ʷ�ֶ�
    size_t m_entries_log;                   // PHT�����Ķ���
    allocator<SaturatingCnt> m_alloc;
    allocator<ShiftReg>  ghr_alloc;

    public:
        // Constructor
        // param:   ghr_width:      Width of GHR
        //          entry_num_log:  PHT�������Ķ���
        //          scnt_width:     ���ͼ�������λ��, Ĭ��ֵΪ2
        GlobalHistoryPredictor(size_t ghr_width, size_t entry_num_log, size_t scnt_width = 2)
        {
            // TODO:
            m_entries_log = entry_num_log;

            m_scnt = m_alloc.allocate(1 << entry_num_log);      // Allocate memory for BHT
            for (int i = 0; i < (1 << entry_num_log); i++)
                m_alloc.construct(m_scnt + i, scnt_width);      // Call constructor of SaturatingCnt



            m_ghr =  ghr_alloc.allocate(1);
            ghr_alloc.construct(m_ghr,ghr_width);
          



        }

        // Destructor
        ~GlobalHistoryPredictor()
        {
            // TODO
            for (int i = 0; i < (1 << m_entries_log); i++)
                m_alloc.destroy(m_scnt + i);

            m_alloc.deallocate(m_scnt, 1 << m_entries_log);
            free(m_ghr);
        }

        // Only for TAGE: return a tag according to the specificed address
        UINT128 get_tag(ADDRINT addr)
        {
            // TODO
            UINT128 ghr_val =m_ghr->getVal();
            UINT128 tag_p = hash(addr,ghr_val);
            //ADDRINT  tag = truncate(tag_p,m_entries_log);
             ADDRINT  tag = truncate(tag_p,tag_size);
            return tag;
        }

        // Only for TAGE: return GHR's value
        UINT128 get_ghr()
        {
            // TODO
            return m_ghr->getVal();
        }

        // Only for TAGE: reset a saturating counter to default value (which is weak taken)
        void reset_ctr(ADDRINT addr)
        {
            // TODO
            UINT128 ghr_val =m_ghr->getVal();
            UINT128 tag_p = hash(addr,ghr_val);
            ADDRINT  tag = truncate(tag_p,m_entries_log);

            m_scnt[tag].set_weak();

            //printf("%ld,",(ADDRINT)m_scnt[tag].getVal());
        }

        bool predict(ADDRINT addr)
        {
            // TODO: Produce prediction according to GHR and PHT

            UINT128 ghr_val =m_ghr->getVal();
            UINT128 tag_p = hash(addr,ghr_val);
            ADDRINT  tag = truncate(tag_p,m_entries_log);
            return m_scnt[tag].isTaken();
        }

        void update(bool takenActually, bool takenPredicted, ADDRINT addr)
        {
            // TODO: Update GHR and PHT according to branch results and prediction
            UINT128 ghr_val =m_ghr->getVal();
            UINT128 tag_p = hash(addr,ghr_val);
            ADDRINT  tag = truncate(tag_p,m_entries_log);

            //UINT8 val = m_scnt[tag].getVal();

            if(takenActually){ //������ת
              
               if(m_scnt[tag].half_sub_one()){
                      m_scnt[tag].set_weak();
               }else{
                  m_scnt[tag].increase();
               }
            }else{
              if(m_scnt[tag].half_()){
                    m_scnt[tag].set_zero();
              }else{
                 m_scnt[tag].decrease();
              }
            }


            m_ghr->shiftIn(takenActually);

        }
};

/* ===================================================================== */
/* Tournament predictor: Select output by global/local selection history */
/* ===================================================================== */
class TournamentPredictor: public BranchPredictor
{
    BranchPredictor* m_BPs[2];      // Sub-predictors
    SaturatingCnt* m_gshr;          // Global select-history register

    bool prediction0,prediction1;
    //allocator<SaturatingCnt> m_alloc;
   // int cnt = 4;
    public:
        TournamentPredictor(BranchPredictor* BP0, BranchPredictor* BP1, size_t gshr_width = 2)
        {
            // TODO
            m_BPs[0] = BP0;
            m_BPs[1] = BP1;

           m_gshr = (SaturatingCnt*)malloc(gshr_width);
          // memset(m_gshr,0,gshr_width);
           // m_gshr = m_alloc.allocate(1);      // Allocate memory for BHT
            //m_alloc.construct(m_scnt , gshr_width);
        }

        ~TournamentPredictor()
        {
            // TODO
            free(m_gshr);
        }


        bool predict(ADDRINT addr)
        {
            // TODO: Produce prediction according to GHR and PHT
          
            prediction0 = m_BPs[0]->predict(addr);
           
            prediction1 = m_BPs[1]->predict(addr);
           
          // if(cnt){
          // printf("%d:gshr:%d,%d,p0:%d,p1:%d>>>\n",cnt,m_gshr->getVal(),m_gshr->isTaken(),prediction0,prediction1);
            
          // }
            if(m_gshr->isTaken()){//���λΪ��
                return  prediction0;
            }else{
                return prediction1;
            }
        }

         void update(bool takenActually, bool takenPredicted, ADDRINT addr)
        {
            // TODO: Update GHR and PHT according to branch results and prediction
          //������Ԥ����
          m_BPs[0]->update(takenActually,takenPredicted,addr);
          m_BPs[1]->update(takenActually,takenPredicted,addr);

          //����gshr
          bool A = (prediction0 == takenActually && prediction1 != takenActually);
          bool B = (prediction1 == takenActually && prediction0 != takenActually);

          // if(cnt){
          //  printf("Update:A:%d,B:%d,TA:%d,TP:%d>>>\n",A,B,takenActually,takenPredicted);
            
          //  }
            

          if(A){
               //printf("gshr应该减小\n");
              // cnt--;
                m_gshr->decrease();
                if(m_gshr->getVal()==2){
                    m_gshr->decrease();
                }
          }else if(B){
              // printf("gshr应该增大\n");
                m_gshr->increase();
                if(m_gshr->getVal()==1){
                    m_gshr->increase();
                }
          }

        }

        // TODO
};

/* ===================================================================== */
/* TArget GEometric history length Predictor                             */
/* ===================================================================== */

template<UINT128 (*hash1)(UINT128 pc, UINT128 ghr), UINT128 (*hash2)(UINT128 pc, UINT128 ghr)>
class TAGEPredictor: public BranchPredictor
{
    const size_t m_tnum;            // ��Ԥ�������� (T[0 : m_tnum - 1])
    const size_t m_entries_log;     // ��Ԥ����T[1 : m_tnum - 1]��PHT�����Ķ���
    BranchPredictor** m_T;          // ��Ԥ����ָ������
    bool* m_T_pred;                 // ���ڴ洢����Ԥ���Ԥ��ֵ
    UINT8** m_useful;               // usefulness matrix
    int provider_indx;              // Provider's index of m_T
    int altpred_indx;               // Alternate provider's index of m_T
    const size_t m_rst_period;      // Reset period of usefulness
    size_t m_rst_cnt;               // Reset counter
    bool flag;

   // ADDRINT cnt = 0;

    public:
        // Constructor
        // param:   tnum:               The number of sub-predictors
        //          T0_entry_num_log:   ��Ԥ����T0��BHT�����Ķ���
        //          T1ghr_len:          ��Ԥ����T1��GHRλ��
        //          alpha:              ����Ԥ����T[1 : m_tnum - 1]��GHR���α�����ϵ
        //          Tn_entry_num_log:   ����Ԥ����T[1 : m_tnum - 1]��PHT�����Ķ���
        //          scnt_width:         Width of saturating counter (3 by default)
        //          rst_period:         Reset period of usefulness
        TAGEPredictor(size_t tnum, size_t T0_entry_num_log, size_t T1ghr_len, float alpha, size_t Tn_entry_num_log, size_t scnt_width = 3, size_t rst_period = 256*1024)
        : m_tnum(tnum), m_entries_log(Tn_entry_num_log), m_rst_period(rst_period), m_rst_cnt(0)
        {
            m_T = new BranchPredictor* [m_tnum];
            m_T_pred = new bool [m_tnum];
            m_useful = new UINT8* [m_tnum];

            //m_T[0] = new BHTPredictor(1 << T0_entry_num_log);//传进去的是1<<T0_entry_num_log
             m_T[0] = new BHTPredictor(T0_entry_num_log);                //构造函数又作了一次,使得BHT长度为1<<(1<<T0_entry_num_log)越界
            size_t ghr_size = T1ghr_len;
            //m_T[0] = new GlobalHistoryPredictor<hash1>(ghr_size, m_entries_log, scnt_width);
            for (size_t i = 1; i < m_tnum; i++)
            {
                m_T[i] = new GlobalHistoryPredictor<hash1>(ghr_size, m_entries_log, scnt_width);
                ghr_size = (size_t)(ghr_size * alpha);

                m_useful[i] = new UINT8 [1 << m_entries_log];
                memset(m_useful[i], 0, sizeof(UINT8)*(1 << m_entries_log));
            }
        }

        ~TAGEPredictor()
        {
            for (size_t i = 0; i < m_tnum; i++) delete m_T[i];
            for (size_t i = 0; i < m_tnum; i++) delete[] m_useful[i];

            delete[] m_T;
            delete[] m_T_pred;
            delete[] m_useful;
      
        }

        bool predict(ADDRINT addr)
        {
           // TODO
           for(size_t i = 0;i<m_tnum;i++){
               
             m_T_pred[i] = m_T[i]->predict(addr);
                
           }
            
      
            //初始化为T0
            provider_indx=0;
            altpred_indx=0;

            for(size_t i=1;i<m_tnum;i++){
                UINT128 tag = hash2(addr,m_T[i]->get_ghr());
                //ADDRINT real_tag = truncate(tag,m_entries_log);
                ADDRINT real_tag = truncate(tag,tag_size);
               //printf("%ld",real_tag);
               
               if(real_tag == m_T[i]->get_tag(addr)){//    
                    altpred_indx = provider_indx;
                    provider_indx = i;

                    
                  //  printf("%d",provider_indx);
                }
            }

            m_rst_cnt++;//ÿ η ֧  1
            //  printf("%d",provider_indx);
           // printf("%d",altpred_indx);
          // printf("%ld\n",(ADDRINT)m_T[provider_indx]->get_tag(addr));
       
        
          
            return m_T_pred[provider_indx];

           // return true;


        }

        void update(bool takenActually, bool takenPredicted, ADDRINT addr)
        {
          // TODO: Update provider itself
            // m_T[0]->update(takenActually,takenPredicted,addr);//报错C: [tid:148051] Tool (or Pin) caused signal 11 at PC 0x7eff55895971
                                                                 //Segmentation fault(已解决)
             
             m_T[provider_indx]->update(takenActually,takenPredicted,addr);
          
                // TODO: Update usefulness
            if(m_T_pred[provider_indx]!=m_T_pred[altpred_indx]){
                //UINT128 tag = m_T[provider_indx]->get_tag(addr);
               // UINT128 tag = hash2(addr,m_T[provider_indx]->get_ghr());
               UINT128 tag = truncate(hash1(addr,m_T[provider_indx]->get_ghr()),m_entries_log);
               if(takenActually == takenPredicted){
                  m_useful[provider_indx][tag]++;
               }else{
                  if(m_useful[provider_indx][tag]>0)
                  m_useful[provider_indx][tag] --;
               }
            }

            // TODO: Reset usefulness periodically
            if(m_rst_cnt == m_rst_period){// ﵽ    
                m_rst_cnt =0;
                 for (size_t i = 1; i < m_tnum; i++)
              {
                 memset(m_useful[i], 0, sizeof(UINT8)*(1 << m_entries_log));
              }
            }

            // TODO: Entry replacement

          if(takenActually != takenPredicted){
            for(size_t i = provider_indx+1; i < m_tnum; i++){
               // UINT128 tag = m_T[i]->get_tag(addr);
                UINT128 tag = truncate(hash1(addr,m_T[provider_indx]->get_ghr()),m_entries_log);
                flag = 0;
                if(m_useful[i][tag]==0){
                   // printf("更新");
                    m_T[i]->update(takenActually,takenPredicted,addr);
                    m_T[i]->reset_ctr(addr);
                    flag = 1;
                    break;
                }

            }
            if(!flag){
            for(size_t i = provider_indx+1; i < m_tnum; i++){
               // UINT128 tag = m_T[i]->get_tag(addr);
                //printf("---");
                UINT128 tag = truncate(hash1(addr,m_T[provider_indx]->get_ghr()),m_entries_log);
                m_useful[i][tag]--;
              }
            }

          }

        }
};



// This function is called every time a control-flow instruction is encountered
void predictBranch(ADDRINT pc, BOOL direction)
{
    BOOL prediction = BP->predict(pc);
    BP->update(direction, prediction, pc);
    if (prediction)
    {
        if (direction)
            takenCorrect++;
        else
            takenIncorrect++;
    }
    else
    {
        if (direction)
            notTakenIncorrect++;
        else
            notTakenCorrect++;
    }
}

// Pin calls this function every time a new instruction is encountered
void Instruction(INS ins, void * v)
{
    if (INS_IsControlFlow(ins) && INS_HasFallThrough(ins))
    {
        // Insert a call to the branch target
        INS_InsertCall(ins, IPOINT_TAKEN_BRANCH, (AFUNPTR)predictBranch,
                        IARG_INST_PTR, IARG_BOOL, TRUE, IARG_END);

        // Insert a call to the next instruction of a branch
        INS_InsertCall(ins, IPOINT_AFTER, (AFUNPTR)predictBranch,
                        IARG_INST_PTR, IARG_BOOL, FALSE, IARG_END);
    }
}

// This knob sets the output file name
KNOB<string> KnobOutputFile(KNOB_MODE_WRITEONCE, "pintool", "o", "brchPredict.txt", "specify the output file name");

// This function is called when the application exits
VOID Fini(int, VOID * v)
{
	double precision = 100 * double(takenCorrect + notTakenCorrect) / (takenCorrect + notTakenCorrect + takenIncorrect + notTakenIncorrect);

    cout << "takenCorrect: " << takenCorrect << endl
    	<< "takenIncorrect: " << takenIncorrect << endl
    	<< "notTakenCorrect: " << notTakenCorrect << endl
    	<< "nnotTakenIncorrect: " << notTakenIncorrect << endl
    	<< "Precision: " << precision << endl;

    OutFile.setf(ios::showbase);
    OutFile << "takenCorrect: " << takenCorrect << endl
    	<< "takenIncorrect: " << takenIncorrect << endl
    	<< "notTakenCorrect: " << notTakenCorrect << endl
    	<< "nnotTakenIncorrect: " << notTakenIncorrect << endl
    	<< "Precision: " << precision << endl;

    OutFile.close();
    delete BP;
}

/* ===================================================================== */
/* Print Help Message                                                    */
/* ===================================================================== */

INT32 Usage()
{
    cerr << "This tool counts the number of dynamic instructions executed" << endl;
    cerr << endl << KNOB_BASE::StringKnobSummary() << endl;
    return -1;
}

/* ===================================================================== */
/* Main                                                                  */
/* ===================================================================== */
/*   argc, argv are the entire command line: pin -t <toolname> -- ...    */
/* ===================================================================== */

int main(int argc, char * argv[])
{
    // TODO: New your Predictor below.
    //BP = new BranchPredictor();
     //BP = new BHTPredictor(12,2);
    //BP=new GlobalHistoryPredictor<Hash1>(2, 12, 2);
    //BP = new TournamentPredictor(new GlobalHistoryPredictor<f_xor>(2, 11, 2),new GlobalHistoryPredictor<f_xor1>(2, 11, 2),2);
    //BP = new TournamentPredictor(new GlobalHistoryPredictor<f_xor>(2, 12, 2),new GlobalHistoryPredictor<f_xor1>(2, 12, 2),2);
  
     BP=new TAGEPredictor<Hash1,f_xnor>(5, 10, 2,2,10);
    // Initialize pin
    if (PIN_Init(argc, argv)) return Usage();

    OutFile.open(KnobOutputFile.Value().c_str());

    // Register Instruction to be called to instrument instructions
    INS_AddInstrumentFunction(Instruction, 0);

    // Register Fini to be called when the application exits
    PIN_AddFiniFunction(Fini, 0);

    // Start the program, never returns
    PIN_StartProgram();

    return 0;
}
