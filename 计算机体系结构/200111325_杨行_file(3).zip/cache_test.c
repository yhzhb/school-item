#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <sys/types.h>

#define ARRAY_SIZE (1 << 30)                                    // test array size is 2^28
#define A_SIZE (1 << 10)
#define SIZE_TEST_TIMES 100000000
#define WAY_TEST_TIMES 10000000
#define cs_cnt  5
#define pagesize 4096
//(int) ((double)rand()/RAND_MAX)*1000000  //可以用这个产生大随机数
typedef unsigned char BYTE;										// define BYTE as one-byte type

BYTE array[ARRAY_SIZE];	//容易受预处理的影响										// test array
const int L2_cache_size = 1 << 18;

double get_usec(const struct timeval tp0, const struct timeval tp1)
{
    return 1000000 * (tp1.tv_sec - tp0.tv_sec) + tp1.tv_usec - tp0.tv_usec;
}

// have an access to arrays with L2 Data Cache'size to clear the L1 cache
void Clear_L1_Cache()
{
	memset(array, 0, L2_cache_size);
}

// have an access to arrays with ARRAY_SIZE to clear the L2 cache
void Clear_L2_Cache()
{
	memset(array, 0, ARRAY_SIZE);
}

int Test_Cache_Size()
{
	printf("**************************************************************\n");
	printf("Cache Size Test\n");


    double avg_time[5];
	int size= 3;
	//BYTE *p = (BYTE*)malloc(4096);

	register long int data_size;//数组大小，一个1B,data_size为数组大小，从2^13开始即从8KB开始
    unsigned char data;
    int result = 3;
	for (int i = 0; i <cs_cnt; i++)
	{
	    avg_time[i]=0;
		data_size = (1 << size);
		BYTE *p[data_size];
		Clear_L2_Cache();
    for(register long int index = 0;index < data_size;index += 1) {;
			p[index]=(BYTE*)malloc(1024);
     }
      struct timeval tp[2];
      gettimeofday(&tp[0], NULL);
      for ( register long int j = 0; j < 1<<20 ; ++j)
      {


		for(register long int index = 0;index < data_size;index += 1) {
			memset(p[index],1,1024);
        }

       }
        gettimeofday(&tp[1], NULL);
        avg_time[i] += get_usec(tp[0], tp[1]);
    for(register long int index = 0;index < data_size;index += 1) {
             free(p[index]);
              p[index]=NULL;
            }

        avg_time[i]=avg_time[i]/(data_size*100);


		size++;
	}

	float temp;
	float time;
	size = 3;//从8KB开始
	int cache_size_result = (1 << size);
	time = avg_time[1] - avg_time[0];//
	for (int i = 0; i <cs_cnt; i++)
	{
		printf("[Test_Array_Size = %dKB]      Average access time = %.1f us\n",1<<size,avg_time[i]);
		if (i < cs_cnt-1)
		{
			temp = avg_time[i + 1] - avg_time[i];
			if (temp > time)
			{//在有限范围内找到最大突变
				cache_size_result = (1 << size);
				time = temp;
				result = size;
			}
		}
		size++;
	};

	printf("L1_Cache_Size is %dKB\n",cache_size_result);
	return result+1 ;//直接加了一
	// TODO

	/**
	 * struct timeval tp[2];
	 * gettimeofday(&tp[0], NULL);
	 * func();
	 * gettimeofday(&tp[1], NULL);
	 * time_used = getusec(tp[0], tp[1]);
	 */
}

int Test_Cache_Block(int index, float *avg_time)
{

	unsigned int temp;
    //unsigned char data;
	temp = index;
	unsigned int data;

	for (int i = 0; i < 8; ++i)
	{
	    register int size = temp*sizeof(data);
	    avg_time[i]=0;
	    struct timeval tp[2];
        gettimeofday(&tp[0], NULL);
		for (register int j = 0; j < temp; ++j)
		{//测试temp
			for (register long int k = 0; k < 1 <<20 ; k += temp)
			{


				memset(&array[k], 1, size);

			}

		}
        gettimeofday(&tp[1], NULL);
        avg_time[i]+= get_usec(tp[0], tp[1]);
		temp = temp << 1;
	}

	temp = index;
	float process_time = avg_time[1] - avg_time[0],temp_time;
	int cache_block_result = 4;
	for (int i = 0; i < 8; ++i)
	{
		//cout << "[Block_Size = " << temp << " B]        ";
		printf("[Test_Array_Jump = %dB]        ",temp);
		//cout << "Average access time = " << avg_time[i] << "us " << endl;
		printf("Average access time = %.2fus\n",avg_time[i]/100);
		if (i < 7)
		{
			temp_time = avg_time[i + 1] - avg_time[i];
			if (temp_time > process_time)
			{
				cache_block_result = temp;
				process_time = temp_time;
			}
		}
		temp = temp << 1;
	}
	return cache_block_result;
}


int Test_Way_Count(int array_size_log, int index, float *avg_time){
	int temp;
	int array_steplen;//数组访问跳跃步长
	char data;
	float temp_time;
	float process_time;
	int way_count_result;//结果
    long int array_size = 1 << (array_size_log + 10);
	temp = index;

	for (int i = 0; i < 5; ++i)
	{
		array_steplen = array_size / temp;
		avg_time[i] = 0;
        struct timeval tp[2];
        gettimeofday(&tp[0], NULL);
		for (int j = 0; j < 1<<20; ++j)
		{
			for (int k = 1; k < temp; k += 2)//访问奇数块
			{

				memset(&array[k*array_steplen], 1, array_steplen);

			}
		}
        gettimeofday(&tp[1], NULL);
        avg_time[i] += get_usec(tp[0], tp[1]);

		temp = temp << 1;
	}

	temp = index;
	process_time = avg_time[1] - avg_time[0];
	way_count_result = temp / 2;
	int size =2;
	for (int i = 0; i < 5; ++i)
	{
		//cout << "Way_Count = " << temp / 2 << ", ";
		printf("[Test_Split_Groups =%d]    ",size);
		//cout << "Average access time = " << avg_time[i] << "us " << endl;
		printf("Average access time = %.2fus\n",avg_time[i]/1000);
		if (i < 4)
		{
			temp_time = avg_time[i + 1] - avg_time[i];
			if (temp_time > process_time)
			{
				way_count_result = temp / 2;
				process_time = temp_time;
			}
		}
		temp = temp << 1;
		size =size <<1;
	}
	return way_count_result;
}


void Test_L1C_Block_Size()
{
	printf("**************************************************************\n");
	printf("L1 DCache Block Size Test\n");

	Clear_L1_Cache();											// Clear L1 Cache
	int index = 1;
	float avg_time[8];
	int result;
	result = Test_Cache_Block(index, avg_time);
	printf("L1_Data_Block_Size is %dB\n",result);

	printf("**************************************************************\n");
	// TODO
}

void Test_L2C_Block_Size()
{
	printf("**************************************************************\n");
	printf("L2 Cache Block Size Test\n");

	Clear_L2_Cache();											// Clear L2 Cache

	// TODO
}

void Test_L1C_Way_Count(int i)
{
	printf("**************************************************************\n");
	printf("L1 DCache Way Count Test\n");
	int index = 2;
	int avg_time[5];
	int result;
	result = Test_Way_Count(i, index, avg_time);

	printf("L1_DCache_Way_Count is %d\n",result);
	printf("**************************************************************\n");

	// TODO
}

void Test_L2C_Way_Count()
{
	printf("**************************************************************\n");
	printf("L2 Cache Way Count Test\n");

	// TODO
}

void Test_Cache_Write_Policy()
{
	printf("**************************************************************\n");
	printf("Cache Write Policy Test\n");

	// TODO
}

void Test_Cache_Swap_Method()
{
	printf("**************************************************************\n");
	printf("Cache Replace Method Test\n");

	// TODO
}

void Test_TLB_Size()
{
	printf("**************************************************************\n");
	printf("TLB Size Test\n");

	const int page_size = 1 << 12;								// Execute "getconf PAGE_SIZE" under linux terminal
	int temp = 16;
	int result;

	float avg_time[6];
    for (int i = 0; i < 6; ++i)
	{
	    //Clear_L1_Cache();
		//Clear_L2_Cache();
	  //int *p = (int*)malloc(temp * page_size);
	    //BYTE *p = (BYTE*)malloc(temp * page_size);
	//数组赋值
       int sum = 0;
       struct timeval tp[2];
       gettimeofday(&tp[0], NULL);

	   for(int j=0;j<50000;j++){

		memset(&array[i], 1, temp*page_size);
	  }
     gettimeofday(&tp[1], NULL);
     sum += get_usec(tp[0], tp[1]);

	  avg_time[i] = sum/temp;
//	  free(p);
	  temp = temp << 1;
	}


    temp = 16;
	float process_time = avg_time[1] - avg_time[0], temp_time;
	for (int i = 0; i < 6; ++i)
	{
		//cout << "[Test_TLB_entries = " << temp << " B]        ";
		printf("[Test_TLB_Entries = %d]        ",temp);
		//cout << "Average access time = " << avg_time[i] << "us " << endl;
		printf("Average access time = %.2fus\n",avg_time[i]);
		if (i < 5)
		{
			temp_time = avg_time[i + 1] - avg_time[i];
			if (temp_time > process_time)
			{
				result = temp ;
				process_time = temp_time;
			}
		}
		temp = temp << 1;
	}
	printf("The number of TLB entries is %d\n",result);
    // TODO
}

int main()
{
	int  i = Test_Cache_Size();
	Test_L1C_Block_Size();
	 //Test_L2C_Block_Size();
    //printf("tets:%d**********\n",i);
	Test_L1C_Way_Count(i);
	// Test_L2C_Way_Count();
	// Test_Cache_Write_Policy();
	// Test_Cache_Swap_Method();
	Test_TLB_Size();

	return 0;
}

