#include <stdlib.h>
#include <stdio.h>
#include "extmem.h"

#define R_BLOCK_NUM 16
#define S_BLOCK_NUM 32
#define IN_BLOCK 8      //����������¼��Ŀ���
#define GROUP    8     //ÿ�����ڵ�Ԫ������һ��������ţ�������Ч������
#define MAX 1000000

#define R_index_disk  70


int LinearSearch(int save_disk,int begin,int end,int find);
int TPMMS(int save_disk);
int find_min(int *max_x,int *max_y,int *x,int *y,int num);
//int merge(int save_disk,int block_num,int disk_id,Buffer buf,char *str);
int IndexSearch(int save_disk,int data_disk,int index_disk,int find);
int make_index(int data_disk,int index_disk,int num);
int print_check(int begin,int end);
int SortLink(int save_disk,int s_begin,int r_begin);
void search_by_index(int *start,int *end,int find,int data_disk,int index_disk,int end_index);
int AND(int save_disk,int begin);
int OR(int save_disk,int begin);
int SUB(int save_disk,int begin);
int main(int argc, char **argv){
     printf("------------------------------------------\n");
     printf("��������������ѡ���㷨 S.C=128\n");
     printf("------------------------------------------\n");
     LinearSearch(50,1+R_BLOCK_NUM,R_BLOCK_NUM+S_BLOCK_NUM,128);
     printf("------------------------------------------\n");
     printf("���׶ζ�·�鲢�����㷨\n");
     printf("------------------------------------------\n");
     TPMMS(200);
     printf("------------------------------------------\n");
     printf("����������ѡ���㷨 S.C=128\n");
     printf("------------------------------------------\n");
    // IndexSearch(60,400,500,159);
    // IndexSearch(60,400,500,158);
     IndexSearch(60,400,500,128);
     printf("------------------------------------------\n");
     printf("��������������㷨\n");
     printf("------------------------------------------\n");
     SortLink(600,400,300);
     printf("------------------------------------------\n");
     printf("��������ļ��ϵĽ��㷨\n");
     printf("------------------------------------------\n");
     AND(750,200);
     printf("------------------------------------------\n");
     printf("��������ļ��ϵĲ��㷨\n");
     printf("------------------------------------------\n");
     OR(800,200);
     printf("------------------------------------------\n");
     printf("��������ļ��ϵĲ��㷨\n");
     printf("------------------------------------------\n");
     SUB(900,200);
     return 0;
}


int LinearSearch(int save_disk,int begin,int end,int find){
     Buffer buf;//���建����
     int disk_id = save_disk;
     unsigned char *blk; /* A pointer to a block */
     unsigned char *blk_ptr;//

     if (!initBuffer(520, 64, &buf))
     {
       perror("Buffer Initialization Failed!\n");
       return -1;
     }
      /* Get a new block in the buffer */
     blk = getNewBlockInBuffer(&buf);
     blk_ptr=getNewBlockInBuffer(&buf);

     int X = -1;//(X,Y)Ԫ������
     int Y = -1;
     int resultnum=0;
     int count=0;
     char str[5];//���ڴ��S.C S.D

     /* Initialize the buffer */

     for(int j=begin;j<=end;++j)
    {
       printf("�������ݿ�%d\n",j);
       if((blk=readBlockFromDisk(j,&buf))==NULL)
       {
            perror("Reading Block Failed!\n");
            return -1;
       }

        for (int i = 0; i < 7; i++)
        { //һ��blk��7��Ԫ���һ����ַ
            for (int k = 0; k < 4; k++)
            {
                str[k] = *(blk + i*8 + k);
            }
            X = atoi(str);
            //������128��ʼ��һ��ѭ��
            if(X!=find)
            {
                continue;
            }
            resultnum++;

            for (int m = 0; m < 4; m++){
                    *(blk_ptr + m+ count*8) = (char)(str[m]);
            }
            for(int k=0;k < 4;k++){
                str[k] = *(blk + i*8 + k + 4);
            }
            Y = atoi(str);
            printf("(X=%d,Y=%d)\n",X,Y);
            for (int m = 0; m < 4; m++){
                *(blk_ptr + m+ count*8 + 4) = (char)(str[m]);
            }
            count++;
            if(count == 7){//һ����д��7����д�����
                itoa(disk_id+1,str,10);//str��д����һ�����̿�ţ�˳���
                for(int n=0;n<4;n++){
                 *(blk_ptr + n+ count*8) = (char)(str[n]);
                }
                writeBlockToDisk(blk_ptr, disk_id, &buf);
                printf("ע�����д����̣�%d\n",disk_id);
                freeBlockInBuffer(blk_ptr,&buf);
                blk_ptr = getNewBlockInBuffer(&buf);//û������д�����
                disk_id++;
                count = 0;

            }

        }
        freeBlockInBuffer(blk,&buf);
    }

    if(count != 0){
        for(;count<8;count++){
            for(int m=0;m<4;m++){
                *(blk_ptr+count*8+m)=(char)NULL;
                *(blk_ptr+count*8+m+4)=(char)NULL;
            }
        }
        writeBlockToDisk(blk_ptr, disk_id, &buf);
        printf("ע�����д����̣�%d\n",disk_id);
        freeBlockInBuffer(blk_ptr,&buf);
    }
    printf("����������Ԫ��һ����%d��\n",resultnum);
    printf("IO��дһ��%d��\n\n",buf.numIO);
    freeBuffer(&buf);
   // print_check(50,51);
    return disk_id;
}

int TPMMS(int save_disk){
    Buffer buf; /* A buffer */
    unsigned char *blk[IN_BLOCK]; /* ָ���ڴ�İ˸���*/
    int disk_id = save_disk;
    /* Initialize the buffer */
    if (!initBuffer(520, 64, &buf))
    {
        perror("Buffer Initialization Failed!\n");
        return -1;
    }


    int X=-1;
    int Y=-1;
    int flag = 0;
    char temp;
    char *min;
    char str[5];


    //��һ�׶Σ�������ѡ������
    for(int i=1;i<=R_BLOCK_NUM+S_BLOCK_NUM;i+= IN_BLOCK){//����1~48��
        for(int j=i;j<i+IN_BLOCK;j++){
            blk[j-i] = readBlockFromDisk(j, &buf);//ͨ���ò�¼���Ӧ�顣ˢ��ָ��
        }
        //һ��¼��8���飬������7��Ԫ����Ч������������ţ���������
        for(int j=0;j<8*GROUP-1;j++){
            if( j %8 ==7 ){//�����洢������ŵ�Ԫ��
                j++;
            }

            min = blk[j/8] + 8*(j-(j/8)*8);//����������һ��Ϊ��С��,blk[j/8]���ڿ����ַ
                                           //8*(j-(j/8)*8)Ϊ����ƫ�Ƶ�ַ
                                           //j���
            for(int k=0;k <4 ;k++){
                str[k]=*(min+k);
            }
            int min_X = atoi(str);
            for(int k=0;k <4 ;k++){
                str[k]=*(min+k+4);
            }
            int min_Y = atoi(str);

            for(int m = j+1;m<8*GROUP;m++){//��ʼ�ȽϺ����Ԫ��
                if(m % 8 == 7 )
                    continue; //�������������λ�ò���

                for (int k = 0; k < 4; k++)
                {
                    str[k] = *(blk[m/8] + (m-(m/8)*8)*8 + k);
                }
                X = atoi(str);
                for (int k = 0; k < 4; k++)
                {
                    str[k] = *(blk[m/8] + (m-(m/8)*8)*8 + k + 4);
                }
                Y = atoi(str);
                if(X<min_X || (X==min_X && Y<min_Y)){
                    min=blk[m/8] + (m-(m/8)*8)*8;
                    min_X=X;
                    min_Y=Y;
                    flag = 1;//���ڸ�Сֵ
                }

            }

            if(flag == 1){//��Ҫ����
                for(int k = 0;k<4;k++){
                    temp = *(blk[j/8] + 8*(j-(j/8)*8)+k);
                    *(blk[j/8] + 8*(j-(j/8)*8)+k) = *(min+k);//����X�����
                    *(min+k)=temp;
                    temp = *(blk[j/8] + 8*(j-(j/8)*8)+k + 4);
                    *(blk[j/8] + 8*(j-(j/8)*8)+k + 4) = *(min + k + 4);//����Y�����
                    *(min+k+4)=temp;
                }

            }

        }


        //¼�������ţ�д����С��
        for(int i=0;i<IN_BLOCK;i++){//�Ի�������8�������
            itoa(disk_id+1,str,10);
            for(int m=0;m<4;m++){
                *(blk[i] + 7*8  + m) = str[m];
            }
            writeBlockToDisk(blk[i], disk_id, &buf);
            freeBlockInBuffer(blk[i],&buf);
            disk_id++;
        }

    }
   // print_check(200,247);



    //�ڶ��׶Σ��鲢
    int r_disk_id=disk_id + 100-disk_id % 100;
    int s_disk_id=r_disk_id + 100;
    //merge(save_disk,R_BLOCK_NUM,r_disk_id,buf,str,2);
    //merge(save_disk+R_BLOCK_NUM,S_BLOCK_NUM/2,merge(save_disk,R_BLOCK_NUM,r_disk_id,buf,str),buf,str);
    merge(save_disk+R_BLOCK_NUM+S_BLOCK_NUM/2,S_BLOCK_NUM/2,merge(save_disk+R_BLOCK_NUM,S_BLOCK_NUM/2,merge(save_disk,R_BLOCK_NUM,r_disk_id,buf,str,2,0),buf,str,2,0),buf,str,2,0);
    merge(r_disk_id+R_BLOCK_NUM,S_BLOCK_NUM,s_disk_id,buf,str,2,0);

   // merge(r_disk_id+R_BLOCK_NUM,S_BLOCK_NUM,merge(save_disk+R_BLOCK_NUM+S_BLOCK_NUM/2,S_BLOCK_NUM/2,merge(save_disk+R_BLOCK_NUM,S_BLOCK_NUM/2,merge(save_disk,R_BLOCK_NUM,r_disk_id,buf,str),buf,str),buf,str),buf,str);


   //printf("ok");
   printf("��ϵ R �����������ļ� %d.blk �� %d.blk\n",r_disk_id,r_disk_id+R_BLOCK_NUM-1);
   printf("��ϵ S �����������ļ� %d.blk �� %d.blk\n",s_disk_id,s_disk_id+S_BLOCK_NUM-1);
   printf("IO��дһ��%d��\n\n", buf.numIO); /* Check the number of IO's */
   //print_check(r_disk_id,r_disk_id+R_BLOCK_NUM-1);
   //print_check(s_disk_id,s_disk_id+S_BLOCK_NUM-1);
   freeBuffer(&buf);
   return 0;


}



int find_min(int *min_x,int *min_y,int *x,int *y,int num){
    *min_x=x[0];
    //printf("%d  ",*min_x);
    *min_y=y[0];
    //printf("%d  ",*min_y);
    int index = 0;


    for(int i=1;i<num;i++){

        if(*min_x > x[i]){
            *min_x = x[i];
            *min_y = y[i];
            index = i;
        }else if(*min_x == x[i]){
           if(*min_y > y[i]){
            *min_y = y[i];
            index = i;
           }
        }
    }
    return index;//���صڼ���
}

int make_index(int data_disk,int index_disk,int num){
    Buffer buf; /* A buffer */
    char str[5];
    int index_id = index_disk;
    int data_id = data_disk;
    unsigned char *f_blk;
    unsigned char *i_blk;//
    int count = 0;//����д��
     if (!initBuffer(520, 64, &buf))
    {
        perror("Buffer Initialization Failed!\n");
        return -1;
    }
    f_blk=getNewBlockInBuffer(&buf);

    for(int i = data_id;i<data_id+num;i++){
            i_blk = readBlockFromDisk(i,&buf);
            itoa(i,str,10);//��¼���ݿ��
            for(int k=0;k<4;k++){
                *(f_blk+count*8+k)=*(i_blk+k);//Ԫ������Ϊ�ÿ�ĵ�һ��S.C�Լ����
                *(f_blk+count*8+k+4) = str[k];
            }
            count++;

            if(count == 7){
                itoa(index_id+1,str,10);
                for(int k=0;k<4;k++){
                    *(f_blk+count*8+k)=str[k];
                }
                writeBlockToDisk(f_blk,index_id,&buf);
                freeBlockInBuffer(f_blk,&buf);
                f_blk=getNewBlockInBuffer(&buf);
                count =0;
                index_id++;
            }
         freeBlockInBuffer(i_blk,&buf);
    }
    if(count != 0){//buf��f_blkδ����������ʣ��λ�ò������һ��������Ӧ�ò��ü�¼����λ��
        for(;count<8;count++){
            for(int m=0;m<4;m++){
                *(f_blk+count*8+m)=(char)NULL;
                *(f_blk+count*8+m+4)=(char)NULL;
            }
        }
        writeBlockToDisk(f_blk, index_id, &buf);
       // index_id++;
    }
    freeBlockInBuffer(i_blk,&buf);
    freeBlockInBuffer(f_blk,&buf);
    freeBuffer(&buf);
    return index_id;
}


int print_check(int begin,int end){
   Buffer buf;
   int X;
   int Y;
   char str[5];
   if (!initBuffer(520, 64, &buf))
    {
        perror("Buffer Initialization Failed!\n");
        return -1;
    }
   unsigned char *p_blk; //������ʾ������������м���
   for(int i=begin;i<=end;i++){
        p_blk=readBlockFromDisk(i,&buf);
        printf("����%d:  ",i);
        for(int j=0;j<7;j++){
           for(int m=0;m<4;m++){
              str[m] = *(p_blk + 8*j + m);
               // strr[m] = *(p_blk + 8*j +4 + m);
            }
            X = atoi(str);
            for(int m=0;m<4;m++){
              str[m] = *(p_blk + 8*j + m+4);
               // strr[m] = *(p_blk + 8*j +4 + m);
            }
            Y = atoi(str);
            printf("(%d,%d)  ",X,Y);
         }

        printf("\n");
        freeBlockInBuffer(p_blk,&buf);
    }
    freeBlockInBuffer(p_blk,&buf);
    freeBuffer(&buf);
}


int IndexSearch(int save_disk,int data_disk,int index_disk,int find){
    int end_index =  make_index(data_disk,index_disk,S_BLOCK_NUM);
   // print_check(index_disk,end_index);
    Buffer buf; /* A buffer */

    int start_blk=-1;
    int end_blk=-1;//������Χ����ʼ���
    int temp = data_disk;//ǰһ����ţ���ʼʱΪ��һ����ţ���һ��ʱ���ֲ���
    char str[5];
    unsigned char *i_blk;//������������ݿ�
    unsigned char *f_blk;//д���ݿ�
    int value;
    int value_blk;
    int before_value = 0;
    if (!initBuffer(520, 64, &buf))
    {
        perror("Buffer Initialization Failed!\n");
        return -1;
    }


    for(int i=index_disk;i<=end_index ;i++){
       // start_blk = -1;
        i_blk=readBlockFromDisk(i,&buf);
        printf("����������%d\n",i);
        for(int j=0; j<7;j++){
            for(int m=0;m<4;m++){
                str[m] = *(i_blk + 8*j + m);

            }
            value = atoi(str);
             for(int m=0;m<4;m++){
                str[m] = *(i_blk + 8*j +4 + m);
            }
            value_blk = atoi(str);
           // printf("%d %d\n",value,value_blk);
            if(value>find && value_blk == data_disk){//��һ���ʹ����˳�ֱ��û��
                break;
            }
            if(value >= find && before_value < find){//value��ǰֵ���ڵ���find,��֮ǰ��valueС��find
                start_blk = temp;
            }
            if(value > find){//valueȷʵ��find����һ������ǽ�����
                end_blk = temp;
                break;
            }
            if( value==0 && find == before_value){
                end_blk = temp;
                break;
            }
            if(value == 0 && find >before_value){
                  start_blk= temp;
                  end_blk  = temp;
                  break;
            }
            temp = value_blk;
            before_value = value;
        }
        if(start_blk == -1)
            printf("û������������Ԫ��\n");
        freeBlockInBuffer(i_blk,&buf);
        if(end_blk!=-1){
            break;
        }
    }

    //printf("start:%d  end:%d\n",start_blk,end_blk);
   // print_check(start_blk,end_blk);
    return LinearSearch(save_disk,start_blk,end_blk,find);
}


void search_by_index(int *start,int *end,int find,int data_disk,int index_disk,int end_index){
    Buffer buf; /* A buffer */

    int start_blk;
    int end_blk=-1;//������Χ����ʼ���
    int temp = data_disk;//ǰһ����ţ���ʼʱΪ��һ����ţ���һ��ʱ���ֲ���
    char str[5];
    unsigned char *i_blk;//������������ݿ�
    int value;
    int value_blk;
    int before_value = 0;
    if (!initBuffer(520, 64, &buf))
    {
        perror("Buffer Initialization Failed!\n");
        return -1;
    }


    for(int i=index_disk;i<=end_index ;i++){
        //start_blk = -1;
        i_blk=readBlockFromDisk(i,&buf);
      //  printf("����������%d\n",i);
        for(int j=0; j<7;j++){
            for(int m=0;m<4;m++){
                str[m] = *(i_blk + 8*j + m);

            }
            value = atoi(str);
             for(int m=0;m<4;m++){
                str[m] = *(i_blk + 8*j +4 + m);
            }
            value_blk = atoi(str);
           // printf("%d %d\n",value,value_blk);
            if(value>find && value_blk == data_disk){//��һ���ʹ����˳�ֱ��û��
                break;
            }
            if(value >= find && before_value < find){//value��ǰֵ���ڵ���find,��֮ǰ��valueС��find
                start_blk = temp;
            }
            if(value > find){//valueȷʵ��find����һ������ǽ�����
                end_blk = temp;
                break;
            }

            if(value==0 && find == before_value){
                end_blk = temp;
                break;
            }
            if(value == 0 && find >before_value){
                  start_blk= temp;
                  end_blk  = temp;
                  break;
            }
            temp = value_blk;
            before_value = value;
        }
        freeBlockInBuffer(i_blk,&buf);
        if(end_blk!=-1){
            break;
        }
    }


    *start = start_blk;
    *end =  end_blk;

}

int SortLink(int save_disk,int s_begin,int r_begin){
      int end_index = make_index(r_begin,70,R_BLOCK_NUM);//��r��������

      Buffer buf;
      unsigned char *s_blk;//����s
      unsigned char *f_blk;//����д��
      unsigned char *r_blk;
      int disk_id = save_disk;
      char str[5];
      int S_C,S_D,R_A,R_B;
      int count=0;//ͳ�����Ӵ���
      int num = 0;
       if (!initBuffer(520, 64, &buf))
      {
        perror("Buffer Initialization Failed!\n");
        return -1;
      }
      f_blk=getNewBlockInBuffer(&buf);

      for(int i=s_begin;i<s_begin+S_BLOCK_NUM;i++){
           s_blk = readBlockFromDisk(i,&buf);
             //printf("%d\n",i);
           for(int j=0; j<7;j++){//7��Ԫ��
                int begin,end;
                for(int m=0;m<4;m++){
                    str[m] = *(s_blk + 8*j + m);
                    //str_1[m] = *(r_blk[0] + 8*j +4 + m);
                }
                S_C = atoi(str);//sȡ������cֵ

                search_by_index(&begin,&end,S_C,r_begin,R_index_disk,end_index);

                for(int r = begin;r<=end;r++){
                    r_blk = readBlockFromDisk(r,&buf);
                    for(int n=0;n<7;n++){
                        for(int m=0;m<4;m++){
                          str[m] = *(r_blk + 8*n + m);
                          //str_1[m] = *(r_blk[0] + 8*j +4 + m);
                        }
                        R_A=atoi(str);
                       // printf("%d,%d\n",R_A,S_C);
                        if(R_A==S_C){//��������,��S_C,S_D,R_A,R_B��˳��д��Ԫ��
                            count++;
                            for(int m=0;m<4;m++){//д��S
                              *(f_blk+8*num+m)  =*(s_blk + 8*j + m);
                              *(f_blk+8*num+m+4)=*(s_blk + 8*j + m+4);
                            }
                            num++;
                            if(num==7){
                               itoa(disk_id+1,str,10);
                               for(int m=0;m<4;m++){
                                *(f_blk+8*num+m)=str[m];
                               }
                               writeBlockToDisk(f_blk,disk_id,&buf);
                               printf("ע�����д����̣�%d\n",disk_id);
                               freeBlockInBuffer(f_blk,&buf);
                               f_blk=getNewBlockInBuffer(&buf);
                               disk_id++;
                               num = 0;
                            }
                            for(int m=0;m<4;m++){//д��R
                              *(f_blk+8*num+m)  =*(r_blk + 8*n + m);
                              *(f_blk+8*num+m+4)=*(r_blk + 8*n + m+4);
                            }
                            num++;
                            if(num==7){
                               itoa(disk_id+1,str,10);
                               for(int m=0;m<4;m++){
                                *(f_blk+8*num+m)=str[m];
                               }
                               writeBlockToDisk(f_blk,disk_id,&buf);
                               printf("ע�����д����̣�%d\n",disk_id);
                               freeBlockInBuffer(f_blk,&buf);
                               f_blk=getNewBlockInBuffer(&buf);
                               disk_id++;
                               num = 0;
                            }

                        }

                    }

                    freeBlockInBuffer(r_blk,&buf);

                }

           }
         freeBlockInBuffer(s_blk,&buf);
      }

      if(num!=0){
        for(;num<8;num++){
            for(int m=0;m<4;m++){
                *(f_blk+num*8+m)=(char)NULL;
                *(f_blk+num*8+m+4)=(char)NULL;
            }
        }
        writeBlockToDisk(f_blk, disk_id, &buf);
        printf("ע�����д����̣�%d\n",disk_id);
        freeBlockInBuffer(f_blk,&buf);
      }

      //print_check(save_disk,disk_id);
      printf("\n�ܹ�����%d��\n",count);
      return disk_id;

}


int AND(int save_disk,int begin){
      Buffer buf;
      char str[5];
      if (!initBuffer(520, 64, &buf))
      {
        perror("Buffer Initialization Failed!\n");
        return -1;
      }

      int  i =  merge(begin,R_BLOCK_NUM+S_BLOCK_NUM,save_disk,buf,str,6,1);
      print_check(save_disk,i);
      return 0;

}

int OR(int save_disk,int begin){
     // int end_index = make_index(r_begin,R_index_disk,R_BLOCK_NUM);//��r��������
      Buffer buf;
      char str[5];
      if (!initBuffer(520, 64, &buf))
      {
        perror("Buffer Initialization Failed!\n");
        return -1;
      }
      //int i = mergeForOR(begin,R_BLOCK_NUM+S_BLOCK_NUM,save_disk,buf,str);
      int i = merge(begin,R_BLOCK_NUM+S_BLOCK_NUM,save_disk,buf,str,6,2);
       //print_check(save_disk,i);
      return 0;
}


int SUB(int save_disk,int begin){
     Buffer buf;
      char str[5];
      if (!initBuffer(520, 64, &buf))
      {
        perror("Buffer Initialization Failed!\n");
        return -1;
      }
      //mergeForSUB(begin,R_BLOCK_NUM+S_BLOCK_NUM,save_disk,buf,str);
      merge(begin,R_BLOCK_NUM+S_BLOCK_NUM,save_disk,buf,str,6,3);
      return 0;
}
