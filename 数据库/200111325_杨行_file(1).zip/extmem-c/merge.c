#include <stdlib.h>
#include <stdio.h>
#include "extmem.h"
#define MAX 10000

int check_inSR(int index,int before_index);
int check_inR(int index);
int check_inS(int index);


int merge(int save_disk,int block_num,int disk_id,Buffer buf,char *str,int way_num,int function_cho){

  unsigned char *blk[way_num];//R���ݿ������飬��·�鲢����·�鲢
  //����С��7·�鲢,
  unsigned char *f_blk;
  int r_disk_id = disk_id;
  int begin[way_num];
  int ptr[way_num];//�������ݿ���
  int tuple_ptr[way_num];//���ݿ���Ԫ���
  int x[way_num];//���ڴ洢Ԫ��ֵ
  int y[way_num];

  for(int i=0;i<way_num;i++){
    begin[i]=save_disk+(block_num/way_num) *i;
  }

  for(int i=0;i<way_num;i++){
    ptr[i]=begin[i];
  }

  for(int i=0;i<way_num;i++){
    tuple_ptr[i]=0;
    x[i]=-1;
    y[i]=-1;
  }


  int num=0;//��¼��������Ԫ��������д��DISK
  int count=0;//��¼�Ѿ�¼��buf�Ŀ���
  int count_res = 0;


  f_blk=getNewBlockInBuffer(&buf);
  for(int i=0;i<way_num;i++){
    blk[i] = readBlockFromDisk(ptr[i], &buf);
  }

  for(int i=0;i<way_num;i++){
    ptr[i]++;
  }

  int before_x=-1;
  int before_y=-1;
  int before_xs=-1;
  int before_ys=-1;
  int before_xr=-1;
  int before_yr=-1;
  int before_index=-1;

  while(count<=block_num*7){
     int min_x,min_y;
   //  printf("%d\n",count);
     for(int i=0;i<way_num;i++){

        if((tuple_ptr[i] >= 7) && (ptr[i]<begin[i]+block_num/way_num)){//��һ�鵱ǰ����ЧԪ������꣬������һ��
                freeBlockInBuffer(blk[i],&buf);
                blk[i]=readBlockFromDisk(ptr[i], &buf);//����
                ptr[i]++;
              //  count++;
                tuple_ptr[i]=0;
            }

     }


         for(int i=0;i<way_num;i++){
              if(tuple_ptr[i]<7){
                  for(int k=0;k<4;k++){
                    str[k]=*(blk[i]+8*tuple_ptr[i]+k);
                   }
                   x[i]=atoi(str);

                   for(int k=0;k<4;k++){
                      str[k]=*(blk[i]+8*tuple_ptr[i]+k+4);
                   }
                   y[i]=atoi(str);

                }else{
                    x[i]=MAX;
                    y[i]=MAX;
                }
           }

           int index = find_min(&min_x,&min_y,x,y,way_num);

               switch(function_cho){
             case 0:
                  if(min_x!=MAX){
                  count++;
                  itoa(min_x,str,10);
                  for(int k = 0;k<4;k++){
                   *(f_blk + k+ num*8) = str[k];
                  }
                  itoa(min_y,str,10);
                  for(int k=0;k<4;k++){
                  *(f_blk + k+ num*8+4) = str[k];
                  }
                  num++;

                  tuple_ptr[index]++;
                 }
                 break;
             case 1:
                 if(min_x!=MAX&&(min_x!=before_x||min_y!=before_y||(check_inSR(index,before_index)!=1))){//����ֵ
                    tuple_ptr[index]++;
                    before_x = min_x;
                    before_y = min_y;
                    before_index = index;
                    count++;
                  }

                  if(min_x!=MAX && min_x==before_x&&min_y==before_y&&(check_inSR(index,before_index)==1)){
                  count++;
                  printf("(X=%d,Y=%d)\n",min_x,min_y);
                  itoa(min_x,str,10);
                  for(int k = 0;k<4;k++){
                   *(f_blk + k+ num*8) = str[k];
                  }
                  itoa(min_y,str,10);
                  for(int k=0;k<4;k++){
                  *(f_blk + k+ num*8+4) = str[k];
                  }
                  num++;
                  count_res++;
                  tuple_ptr[index]++;
                  before_x = min_x;
                  before_y = min_y;
                  before_index = index;
                 }
                break;
             case 2:
                 if(min_x!=MAX){
                    count++;
                    if(min_x!=before_x||min_y!=before_y){
                   printf("(X=%d,Y=%d)\n",min_x,min_y);
                  itoa(min_x,str,10);
                  for(int k = 0;k<4;k++){
                   *(f_blk + k+ num*8) = str[k];
                  }
                  itoa(min_y,str,10);
                  for(int k=0;k<4;k++){
                  *(f_blk + k+ num*8+4) = str[k];
                  }
                  num++;
                  count_res++;
                  tuple_ptr[index]++;
                  before_x = min_x;
                  before_y = min_y;
                  before_index = index;
                    }

                    else{
                        tuple_ptr[index]++;
                        before_index = index;
                    }
                 }
                 break;
             case 3:
                if(min_x!=MAX){
                  count++;
                  if( (min_x!=before_xr||min_y!=before_yr)&&(check_inS(index)==1)&& (min_x!=before_xs||min_y!=before_ys)){
                  printf("(X=%d,Y=%d)\n",min_x,min_y);
                  itoa(min_x,str,10);
                  for(int k = 0;k<4;k++){
                   *(f_blk + k+ num*8) = str[k];
                  }
                  itoa(min_y,str,10);
                  for(int k=0;k<4;k++){
                  *(f_blk + k+ num*8+4) = str[k];
                  }
                  num++;
                  count_res++;
                  tuple_ptr[index]++;
                  before_xs = min_x;
                  before_ys = min_y;
                  before_index = index;
                  }else{
                    tuple_ptr[index]++;
                    if(check_inR(index)){
                    before_xr = min_x;
                    before_yr = min_y;
                    }else if(check_inS(index)){
                    before_xs = min_x;
                    before_ys = min_y;
                    }
                    before_index = index;
                  }
                 }
                break;

               }

                   if(num==7){
                        itoa(r_disk_id+1,str,10);
                        for(int k=0;k<4;k++){
                           *(f_blk+k+num*8)= str[k];
                        }
                        writeBlockToDisk(f_blk, r_disk_id, &buf);
                        if(function_cho !=0){
                           printf("ע�����д����̣�%d\n",r_disk_id);
                        }
                        freeBlockInBuffer(f_blk,&buf);
                        f_blk=getNewBlockInBuffer(&buf);
                        r_disk_id++;
                        num=0;
                   }

            else if(count == block_num*7){
                if(num!=0){
                for(;num<8;num++){
                for(int m=0;m<4;m++){
                *(f_blk+num*8+m)=(char)NULL;
                *(f_blk+num*8+m+4)=(char)NULL;
               }
             }
                writeBlockToDisk(f_blk, r_disk_id, &buf);
                if(function_cho !=0){
                printf("ע�����д����̣�%d\n",r_disk_id);
                }
                    }
                count++;
                freeBlockInBuffer(f_blk,&buf);
                for(int i=0;i<way_num;i++){
                freeBlockInBuffer(blk[i],&buf);

                }

               }



    }

     switch(function_cho){
    case 1:
         printf("\nS��R�Ľ�����%d��Ԫ��\n",count_res);
         break;
    case 2:
        printf("\nS��R�Ĳ�����%d��Ԫ��\n",count_res);
        break;
    case 3:
        printf("\nS-R��%d��Ԫ��\n",count_res);
        break;
     }
     return r_disk_id;

}




int check_inSR(int index,int before_index){
   if((index>=0&&index<2)&&(before_index<6&&before_index>1)){
    return 1;
   }else if((before_index>=0&&before_index<2)&&(index<6&&index>1)){
     return 1;
   }

   return 0;

}

int check_inR(int index){
   if(index>=0&&index<2){
    return 1;
   }
   return 0;
}

int check_inS(int index){
    if(index<6&&index>1){
     return 1;
   }

   return 0;
}



