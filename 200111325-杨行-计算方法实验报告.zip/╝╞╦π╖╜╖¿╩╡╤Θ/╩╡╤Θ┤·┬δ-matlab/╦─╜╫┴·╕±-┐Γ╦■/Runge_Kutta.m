function res =Runge_Kutta(a,b,alapha,N,fnq)%x��ֵ��x��ֵ ��y��ֵ������ֶ�����΢�ַ��̺���
format long;
n = length(N);
m =length(symvar(fnq));
Var=char(symvar(fnq));
for j =1:n
    fprintf('******************��ǰ������%d*********************\n',N(j));
    x=zeros(N(j)+1,1);
    x(1)=a;
    y=zeros(N(j)+1,1);
    y(1)=alapha;
    h=(b-a)/N(j);
 for i = 1:N(j)
    if(m==2)
   K1 =h*subs(fnq,symvar(fnq),[x(i),y(i)]);
   K2 =h*subs(fnq,symvar(fnq),[x(i)+h/2,y(i)+K1/2]);
   K3 =h*subs(fnq,symvar(fnq),[x(i)+h/2,y(i)+K2/2]);
   K4 =h*subs(fnq,symvar(fnq),[x(i)+h,y(i)+K3]);

    elseif(m==1 && strcmp(Var,'x'))
    K1 =h*subs(fnq,symvar(fnq),x(i));
    K2 =h*subs(fnq,symvar(fnq),x(i)+h/2);
    K3 =h*subs(fnq,symvar(fnq),x(i)+h/2);
    K4 =h*subs(fnq,symvar(fnq),x(i)+h);
        
  
    elseif(m==1 && strcmp(Var,'y'))
    K1 =h*subs(fnq,symvar(fnq),y(i));
    K2 =h*subs(fnq,symvar(fnq),y(i)+K1/2);
    K3 =h*subs(fnq,symvar(fnq),y(i)+K2/2);
    K4 =h*subs(fnq,symvar(fnq),y(i)+K3);    
  
    elseif(m==0)
        K1=h*subs(fnq,symvar(fnq),[]);
        K2=h*subs(fnq,symvar(fnq),[]);
        K3=h*subs(fnq,symvar(fnq),[]);
        K4=h*subs(fnq,symvar(fnq),[]);
    end
    x1=x(i)+h;
    y1=y(i)+(K1+2*K2+2*K3+K4)/6;
    x(i+1)=x1;
    y(i+1)=y1;
 end
 res =[x,y];
 disp(res);
end

    