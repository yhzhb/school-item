N=[5,10,20];

syms x y;
fnq = x+y;
fprintf('************************Q1.1******************\n');
Runge_Kutta(0, 1, -1,N,fnq);

fnq = -y*y;
fprintf('************************Q1.2******************\n');
Runge_Kutta(0, 1, 1,N,fnq);

fnq=2/x * y+x^2*exp(x);
fprintf('************************Q2.1******************\n');
Runge_Kutta(1, 3, 0,N,fnq);

fnq=1/x * (y^2+y);
fprintf('************************Q2.2******************\n');
Runge_Kutta(1, 3, -2,N,fnq);

fnq=-20*(y-x^2)+2*x;
fprintf('************************Q3.1******************\n');
Runge_Kutta(0, 1, 1/3,N,fnq);

fnq=-20*y+20*sin(x)+cos(x);
fprintf('************************Q3.2******************\n');
Runge_Kutta(0, 1, 1,N,fnq);


fnq=-20*(y-exp(x)*sin(x))+exp(x)*(sin(x)+cos(x));
fprintf('************************Q3.3******************\n');
Runge_Kutta(0, 1, 0,N,fnq);
