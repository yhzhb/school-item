syms x;
fnq = 1/(1+x^2);
n=[5,10,20];
fprintf('*****question1.1******\n');
x0=[0.75,1.75,2.75,3.75,4.75];
Lagrangetest(fnq,10,n,-5.0,x0)
fprintf('*****question2.1 �޸ĳ�ֵ******\n');
x0=[-0.95,-0.05,0.05,0.95];
Lagrangetest(fnq,2,n,-1.0,x0)
fprintf('*****question2.1******\n');
Lagrangetest(fnq,2,n,-5.0,x0)

syms x;
fnq = exp(x);
fprintf('*****question1.2******\n');
x0=[-0.95,-0.05,0.05,0.95];
Lagrangetest(fnq,2,n,-5.0,x0)
fprintf('*****question1.2(1)******\n');
Lagrangetest(fnq,2,n,-1.0,x0)
fprintf('*****question2.2******\n');
x0=[-4.75,-0.25,0.25,4.75];
Lagrangetest(fnq,10,n,-5.0,x0)

fprintf('*****question3******\n');
X=[1,4,9];
fx=[1,2,3];
x0=[5,50,115,185];
Lagrange(X,fx,x0);

X=[36,49,64];
fx=[6,7,8];
Lagrange(X,fx,x0);

X=[100,121,144];
fx=[10,11,12];
Lagrange(X,fx,x0);

X=[169,196,225];
fx=[13,14,15];
Lagrange(X,fx,x0);

