fprintf('******Q1******');
syms x;
fnq = x^2 * exp(x);
Romberg(0,1,10^-6,fnq)


fprintf('******Q2******');
fnq =  exp(x)*sin(x);
Romberg(1,3,10^-6,fnq)

fprintf('******Q3******');
fnq = 4/(1+x^2);
Romberg(0,1,10^-6,fnq)

fprintf('******Q4******');
fnq = 1/(x+1);
Romberg(0,1,10^-6,fnq)


