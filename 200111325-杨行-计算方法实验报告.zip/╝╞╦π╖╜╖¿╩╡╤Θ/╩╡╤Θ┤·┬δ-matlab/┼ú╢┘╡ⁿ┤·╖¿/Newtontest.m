
%question1.1
syms x;
fnq = cos(x)-x;

Newton(fnq,pi/4,10^-6,10^-4,10);


%question1.2
syms  x;
fnq = exp(-x)-sin(x);

Newton(fnq,0.6,10^-6,10^-4,10);


%question2.1
sym x;
fnq = x - exp(-x);
Newton(fnq,0.5,10^-6,10^-4,10);

%question2.2
sym x;
fnq = x^2 -2*x*exp(-x) + exp(-2*x);
Newton(fnq,0.5,10^-6,10^-4,20);




