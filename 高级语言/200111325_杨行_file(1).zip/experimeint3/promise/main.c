#include <stdio.h>
#include <math.h>
#define const 1.42e8
int main()
{
    printf("number:200111325\n");
    printf("experiment3-progarm2\n\n");
	int n;
	float i=1,sum=1;
	for(n=2;n<=64;n++)
	{
		i*=2;
		sum+=i;

	}
	printf("sum=%.2f\n",sum);
	printf("volum=%.2f\n",sum/const);

    float term,Sum=0;
	for(n=1;n<=64;n++)
	{
		term=pow(2,n-1);
		Sum+=term;

	}
	printf("Sum=%.2f\n",Sum);
	printf("volum=%.2f\n",Sum/const);
}
