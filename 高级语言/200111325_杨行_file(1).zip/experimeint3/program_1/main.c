#include <stdio.h>
#define N 100
int main()
{
   printf("Number:200111325\nExperiment-3 Program-1\n\n");
   int i,j,k,m,n,f;
   int count=0;
   int p=0;
   int a[N]={0};
   for(i=100;i<=200;i++)
   {
       for(j=2;j<i;j++)
       {
           if(i%j==0)break;
       }
       if(j>=i)
       {
           printf("%d ",i);
           a[p]=i;
           count++;
           p++;
       }
       if(count%10==0&&count!=0)
       {
           count=0;printf("\n");
       }
   }
   printf("\n");
   for(k=0;k<p;k++)
   {
       m=a[k]%10;f=a[k]%100/10;n=a[k]/100;
       printf("%d ",m*100+f*10+n);
       if(count%10==0&&count!=0)
       {
           count=0;
           printf("\n");
       }
       count++;
   }
   return 0;
}

