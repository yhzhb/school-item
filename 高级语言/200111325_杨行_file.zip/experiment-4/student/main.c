#include <stdio.h>
#include <stdlib.h>
int x,y,i,count=0;
int answer,t,sum=0;
int main()
{
   printf("Number:200111325\nExperiment4-Program1\n");
   for(i=1;i<=10;i++)
   {
       srand(time(NULL));
       x=rand()%10+1;
       y=rand()%10+1;
       for(t=0;t<3;  )
       {
           printf("%d*%d=?\n",x,y);
           printf("��������ȷ�Ĵ𰸣�");
           scanf("%d",&answer);
           if(answer==x*y)
         {
           printf("Right!\n");
           sum+=10;
           count++;
           break;
         }
         t++;
         if(answer!=x*y&&t!=3)
         {
            printf("Wrong!Please try again.\n");

         }

          else
         {
           printf("Wrong!Please try next subject.\n");

         }
       }
       printf("�����Ŀ����%d   �������Ŀ����%d\n",count,i);
  }
  printf("�ܷ�Ϊ%d\n",sum);
  printf("�÷���Ϊ%d%%\n",count*10);
}
