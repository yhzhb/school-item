#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int x,y,k,op,res;
float answer,question;
int i,count=0;
int sum=0;
int main()
{
    printf("Number:200111325\nExperiment4-Program2\n");
    char ch;
    do
  {
    for(i=1;i<=10;i++)
    {
        srand((unsigned)time(NULL));
        x=rand()%10+1;
        y=rand()%10+1;
        op=rand()%4+1;
        res=rand()%4+1;
        switch(op)
        {
            case 1:
               ch='+';
               question=x+y;
               break;
            case 2:
               ch='-';
               question=x-y;
               break;
            case 3:
               ch='*';
               question=x*y;
               break;
            case 4:
               ch='/';
               float p,q;
               p=(float)x/y;q=p*100;question=(float)(int)q/100;
               break;
        }
        printf("%d%c%d=?\n��������ȷ�Ĵ𰸣�",x,ch,y);
        scanf("%f",&answer);
        if(answer==question)
        {
            switch(res)
            {
                case 1:printf("Very good!\n");break;
                case 2:printf("Excellent!\n");break;
                case 3:printf("Nice work!\n");break;
                case 4:printf("Keep the good work!\n");break;
            }
            sum+=10;
            count++;
        }
        else
        {
            switch(res)
            {
                case 1:printf("No!Please try next subject.\n");break;
                case 2:printf("Wrong!Be careful.\n");break;
                case 3:printf("Don't give up!\n");break;
                case 4:printf("Not correct.Keep trying!\n");break;
            }
        }
        printf("�Ѵ����Ŀ����%d   �������Ŀ����%d\n",count,i);
    }
    printf("�ܷ�Ϊ%d\n�÷���Ϊ%d%%\n",sum,count*10);
    count=0;
  }while(count*10<75);

}
