/***************************************
**�ļ�����Experiment_6
**���ڣ�2020/10/31
**�����ˣ�����
**����:��������ҵ
** �汾:2.0
******************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define N 30
#define MAX_LINE 10
void ReadScore(char name[][MAX_LINE],long num[],int Score[],int n);
int Calculate(int Score[],int n);
void Datasort(long num[],int Score[],char name[][MAX_LINE],int n);
void SortinD(long num[],int Score[],char name[][MAX_LINE],int n);
void SortinA(long num[],int Score[],char name[][MAX_LINE],int n);
void SortinNum(long num[],int Score[],char name[][MAX_LINE],int n);
void SortinName(long num[],int Score[],char name[][MAX_LINE],int n);
void Search_by_Num(long num[],int Score[],char name[][MAX_LINE],int n);
void Search_by_Name(long num[],int Score[],char name[][MAX_LINE],int n);
void Stana(int Score[],int n);

int main()
{
    int count=0,n,choice=0;
    printf("������ѧ����������");
    scanf("%d",&n);
     while(n<=0)
    {
    printf("������ѧ����������");
    scanf("%d",&n);
    }
    long num[N]={0};int Score[N]={0};char name[N][MAX_LINE];
    printf("1.Input record\n2.Calculate total and average score of course\n3.Sort in descending order by score\n");
    printf("4.Sort in ascending order by score\n5.Sort in ascending order by number\n6.Sort in dictionary order by name\n7.Search by number\n");
    printf("8.Search by name\n9.Statistic analysis\n10.List record\n11.Exit\n");
    do
 {
    printf("Please enter your choice:");
    scanf("%d",&choice);
    count++;
    if(count==1&&choice!=1&&choice!=0)
    {
    	    printf("You haven't input record !\n");
            printf("Please input record.\n");
            choice=1;
	}
    switch(choice)
    {
        case 1:ReadScore(name,num,Score,n);break;
        case 2:Calculate(Score,n);break;
        case 3:SortinD(num,Score,name,n);break;
        case 4:SortinA(num,Score,name,n);break;
        case 5:SortinNum(num,Score,name,n);break;
        case 6:SortinName(num,Score,name,n);break;
        case 7:Datasort(num,Score,name,n);Search_by_Num(num,Score,name,n);break;
        case 8:Datasort(num,Score,name,n);Search_by_Name(num,Score,name,n);break;
        case 9:Stana(Score,n);break;
        case 10:SortinNum(num,Score,name,n);Calculate(Score,n);break;
        case 11:return 0;
    }
   }while (choice>0&&choice<=11);
}

void ReadScore(char name[][MAX_LINE],long num[],int Score[],int n)
{
    int i;
    for(i=0;i<n;i++)
        {
            printf("Please input the student's ID,score and name:");
			scanf("%ld %d",&num[i],&Score[i]);
            scanf("%s",name[i]);
            while(Score[i]>100||Score[i]<0||num[i]<0)
             {
                 printf("Wrong!Please input the student's ID,score and name again:");
                 scanf("%ld %d",&num[i],&Score[i]);
                 scanf("%s",name[i]);
             }
        }
}


int Calculate(int Score[],int n)
{
    int i,sum=0;float ave;
    if (n<0)
        return -1;
    else
  {
    for (i=0;i<n;i++)
    {
        sum+=Score[i];
    }
    ave=(float)sum/n;
    printf("�ܷ�Ϊ%d\nƽ����Ϊ%.3f\n",sum,ave);
    }
}

void Swap(int*x,int*y)
{
    int temp;
    temp=*x;
    *x=*y;
    *y=temp;
}

void Swap2(long*x,long*y)
{
    long temp;
    temp=*x;
    *x=*y;
    *y=temp;
}


void Datasort(long num[],int Score[],char name[][MAX_LINE],int n)
{
    int i,k,j;char temp[MAX_LINE];
    for(i=0;i<n-1;i++)
    {

        for(j=i+1;j<n;j++)
        {
            if(Score[j]>Score[i])
            {
            strcpy(temp,name[i]);
            strcpy(name[i],name[j]);
            strcpy(name[j],temp);
            Swap(&Score[j],&Score[i]);
            Swap2(&num[j],&num[i]);
            }
            else if(Score[j]==Score[i]&&num[j]<num[i])
            {
                strcpy(temp,name[i]);
                strcpy(name[i],name[j]);
                strcpy(name[j],temp);
                Swap2(&num[i],&num[j]);

            }
        }

    }
}

void Datasort_by_name(long num[],int Score[],char name[][MAX_LINE],int n)
{
	int i,j;
	char temp[MAX_LINE];
    for(i=0;i<n-1;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(strcmp(name[j],name[i])<0)
            {
            strcpy(temp,name[i]);
            strcpy(name[i],name[j]);
            strcpy(name[j],temp);
            Swap(&Score[j],&Score[i]);
            Swap2(&num[j],&num[i]);
            }
       }
    }
}
void SortinD(long num[],int Score[],char name[][MAX_LINE],int n)
{
    int i;
    Datasort(num,Score,name,n);
    printf("����\t����\tѧ��\t\t�ɼ�\n");
    for(i=0;i<n;i++)
     {
        printf("%d\t%s\t%ld\t%d\n",i+1,name[i],num[i],Score[i]);
    }
    printf("\n");
}


void SortinA(long num[],int Score[],char name[][MAX_LINE],int n)
{
    int i;
    Datasort(num,Score,name,n);
    printf("����\t����\tѧ��\t\t�ɼ�\n");
    for(i=n-1;i>=0;i--)
    {
        printf("%d\t%s\t%ld\t%d\n",i+1,name[i],num[i],Score[i]);
    }
    printf("\n");
}

void SortinNum(long num[],int Score[],char name[][MAX_LINE],int n)
{
    int i,j;char temp[MAX_LINE];
    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(num[i]>num[j])
            {
            strcpy(temp,name[i]);
            strcpy(name[i],name[j]);
            strcpy(name[j],temp);
            Swap(&Score[j],&Score[i]);
            Swap2(&num[j],&num[i]);
            }
        }
    }
     printf("ѧ��\t\t����\t�ɼ�\n");
     for(i=0;i<n;i++)
     {
        printf("%ld\t%s\t%d\n",num[i],name[i],Score[i]);
     }
    printf("\n");
}



void SortinName(long num[],int Score[],char name[][MAX_LINE],int n)
{
      int i;
	 Datasort_by_name(num,Score,name,n);
     printf("ѧ��\t\t����\t�ɼ�\n");
     for(i=0;i<n;i++)
     {
        printf("%ld\t%s\t%d\n",num[i],name[i],Score[i]);
    }
    printf("\n");
}

void Search_by_Num(long num[],int Score[],char name[][MAX_LINE],int n)
{
    int i,score,rank=0;
    int flag=1;
    long number;
    char temp[MAX_LINE];
    printf("Please input the number:");
    scanf("%ld",&number);
    for(i=0;i<n;i++)
    {
        if(num[i]==number)
        {
            score=Score[i];
            strcpy(temp,name[i]);
            flag=0;
        }
    }
   if(flag==1)
    {
        printf("No found!\n");

    }
    else
    {

    for(i=0;i<n;i++)
    {
        if(Score[i]>score)
        {
            rank+=1;
        }
    }
    printf("���� %s\t���� %d\t���� %d\tѧ�� %ld\n",temp,score,rank+1,number);
    printf("\n");
   }
}

void Search_by_Name(long num[],int Score[],char name[][MAX_LINE],int n)
{

    int i,score,rank=0;int flag=1;long number;char temp[MAX_LINE];
    printf("Please input the name for researching:");
    scanf("%s",temp);
    for(i=0;i<n;i++)
    {
        if(strcmp(name[i],temp)==0)
        {
            score=Score[i];
            number=num[i];
            flag=0;
        }
    }
        if(flag==1)
    {
        printf("No found!\n");

    }
    else
    {
    for(i=0;i<n;i++)
    {
        if(Score[i]>score)
        {
            rank+=1;
        }
    }
    printf("���� %s���� %d,���� %d,ѧ�� %ld\n",temp,score,rank+1,number);
    printf("\n");
	}
}


void Stana(int Score[],int n)
{
    int i;
    int count[5]={0};
    for(i=0;i<n;i++)
    {
        if(Score[i]>=90&&Score[i]<=100)
        {
            count[0]++;
        }
        else if(Score[i]>=80&&Score[i]<=89)
        {
            count[1]++;
        }
        else if(Score[i]>=70&&Score[i]<=79)
        {
            count[2]++;
        }
        else if(Score[i]>=60&&Score[i]<=69)
        {
            count[3]++;
        }
        else if(Score[i]>=0&&Score[i]<=59)
        {
            count[4]++;
        }
    }
    printf("��������Ϊ %d,ռ %f%%\n",count[0],100*(float)count[0]/n);
    printf("��������Ϊ %d,ռ %f%%\n",count[1],100*(float)count[1]/n);
    printf("�е�����Ϊ %d,ռ %f%%\n",count[2],100*(float)count[2]/n);
    printf("��������Ϊ %d,ռ %f%%\n",count[3],100*(float)count[3]/n);
    printf("����������Ϊ %d,ռ %f%%\n",count[4],100*(float)count[4]/n);
    printf("\n");
}

