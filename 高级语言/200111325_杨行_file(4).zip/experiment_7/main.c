/***************************************
**�ļ�����Experiment_7
**���ڣ�2020/11/6
**�����ˣ�����
**����:���ߴ���ҵ
** �汾:3.0
******************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define N 30
#define MAX_LINE 10
#define M 6
void ReadScore(char name[][MAX_LINE],long num[],int Score[][M],int n,int m);
void Calculate(int Score[][M],int n,int m);
void Calculate_by_stduent(int Score[][M],char name[][MAX_LINE],int n,int m);
void Datasort(long num[],int Score[][M],char name[][MAX_LINE],int n,int m);
void SortinD(long num[],int Score[][M],char name[][MAX_LINE],int n,int m);
void SortinA(long num[],int Score[][M],char name[][MAX_LINE],int n,int m);
void SortinNum(long num[],int Score[][M],char name[][MAX_LINE],int n,int m);
void SortinName(long num[],int Score[][M],char name[][MAX_LINE],int n,int m);
void Search_by_Num(long num[],int Score[][M],char name[][MAX_LINE],int n,int m);
void Search_by_Name(long num[],int Score[][M],char name[][MAX_LINE],int n,int m);
void Stana(int Score[][M],int n,int m);

int main()
{
    int count=0,n,m,choice=0;
    long num[N]={0};int Score[N][M]={0};char name[N][MAX_LINE];
    do
    {
    printf("������ѧ���������Ϳγ�����");
    scanf("%d%d",&n,&m);
    }while(n<=0||n>30||m>6);
    printf("1.Input record\n2.Calculate total and average score of every course\n3.Calculate total and average score of every student\n");
    printf("4.Sort in descending order by total score of every student\n5.Sort in ascending order by total score of every student\n6.Sort in ascending order by number\n7.Sort in dictionary order by name\n");
    printf("8.Search by number\n9.Search by name\n10.Statistic analysis\n11.List record\n0.Exit\n");
    do
  {
    printf("Please enter your choice:");
    scanf("%d",&choice);
    count++;
    if(count==1&&choice!=1&&choice!=0)
    {
    	    printf("You haven't input record !\n");
            printf("Please input record.\n");
            choice=1;
	}
	while(count!=1&&choice>11)
    {
      printf("Wrong!Please enter your choice:");
      scanf("%d",&choice);
    }
    switch(choice)
    {
        case 1:ReadScore(name,num,Score,n,m);break;
        case 2:Calculate(Score,n,m);break;
        case 3:Calculate_by_stduent(Score,name,n,m);break;
        case 4:SortinD(num,Score,name,n,m);break;
        case 5:SortinA(num,Score,name,n,m);break;
        case 6:SortinNum(num,Score,name,n,m);break;
        case 7:SortinName(num,Score,name,n,m);break;
        case 8:Datasort(num,Score,name,n,m);Search_by_Num(num,Score,name,n,m);break;
        case 9:Datasort(num,Score,name,n,m);Search_by_Name(num,Score,name,n,m);break;
        case 10:Stana(Score,n,m);break;
        case 11:SortinNum(num,Score,name,n,m);Calculate(Score,n,m);break;
        case 0:return 0;
    }
   }while (choice>0&&choice<=11);
}

void ReadScore(char name[][MAX_LINE],long num[],int Score[][M],int n,int m)
{
    int i,j;
    for(i=0;i<n;i++)
        {
            printf("Please input the student's ID and name:");
			scanf("%ld",&num[i]);
            scanf("%s",name[i]);
            for(j=0;j<m;j++)
            {
                printf("Please input the student's score of subject %d:",j+1);
                scanf("%d",&Score[i][j]);
                while(Score[i][j]>100||Score[i][j]<0)
              {
                 printf("Wrong!Please input the student's score of subject %d again:",j+1);
                 scanf("%d",&Score[i][j]);
              }
            }
        }
}


void Calculate(int Score[][M],int n,int m)
{
    int i,j,sum[M]={0};float ave;
    for(j=0;j<m;j++)
   {
       for (i=0;i<n;i++)
    {
        sum[j]=Score[i][j]+sum[j];
    }
   }
   for(j=0;j<m;j++)
   {
    ave=(float)sum[j]/n;
    printf("subject %d ���ܷ�Ϊ%d\nƽ����Ϊ%.3f\n",j+1,sum[j],ave);
   }
}

void Calculate_by_stduent(int Score[][M],char name[][MAX_LINE],int n,int m)
{
    int i,j,sum[N]={0};float ave;
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
            sum[i]=Score[i][j]+sum[i];
        }
    }
    for(i=0;i<n;i++)
    {
        ave=(float)sum[i]/m;
        printf("student %s ���ܷ�Ϊ%d\nƽ����Ϊ%.3f\n",name[i],sum[i],ave);
    }
}


void Swap(int*x,int*y)
{
    int temp;
    temp=*x;
    *x=*y;
    *y=temp;
}

void Swap2(long*x,long*y)
{
    long temp;
    temp=*x;
    *x=*y;
    *y=temp;
}


void Datasort(long num[],int Score[][M],char name[][MAX_LINE],int n,int m)
{
    int i,k,j,sum[N]={0};char temp[MAX_LINE];
    for(i=0;i<n;i++)
    {
         for(k=0;k<m;k++)
           {
               sum[i]+=Score[i][k];
           }
    }
    for(i=0;i<n-1;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(sum[j]>sum[i])
            {
            strcpy(temp,name[i]);
            strcpy(name[i],name[j]);
            strcpy(name[j],temp);
            Swap(&sum[j],&sum[i]);
            Swap2(&num[j],&num[i]);
            for(k=0;k<m;k++)
               {
                Swap(&Score[j][k],&Score[i][k]);
                }
            }
            else if(sum[j]==sum[i]&&num[j]<num[i])
            {
                strcpy(temp,name[i]);
                strcpy(name[i],name[j]);
                strcpy(name[j],temp);
                Swap2(&num[i],&num[j]);
                for(k=0;k<m;k++)
               {
                Swap(&Score[j][k],&Score[i][k]);
                }

            }
        }
    }
}

void Datasort_by_name(long num[],int Score[][M],char name[][MAX_LINE],int n,int m)
{
	int i,j,k;
	char temp[MAX_LINE];
    for(i=0;i<n-1;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(strcmp(name[j],name[i])<0)
            {
            strcpy(temp,name[i]);
            strcpy(name[i],name[j]);
            strcpy(name[j],temp);
            for(k=0;k<m;k++)
            {Swap(&Score[j][k],&Score[i][k]);}
            Swap2(&num[j],&num[i]);
            }
       }
    }
}
void SortinD(long num[],int Score[][M],char name[][MAX_LINE],int n,int m)
{
    int i,k=0;
    int sum[N]={0};
    Datasort(num,Score,name,n,m);
    printf("����\t����\tѧ��\t");
    while(k<m)
    {
        printf("�γ�%d\t",k+1);
        k++;
    }
    printf("\n");
    for(i=0;i<n;i++)
     {
        printf("%d\t%s\t%ld\t",i+1,name[i],num[i]);
        for(k=0;k<m;k++)
        {
            sum[i]=Score[i][k]+sum[i];
            printf("%d\t",Score[i][k]);
        }
        printf("�ܷ֣�%d\n",sum[i]);
    }
    printf("\n");
}


void SortinA(long num[],int Score[][M],char name[][MAX_LINE],int n,int m)
{
    int i,k=0;int sum[N]={0};
    Datasort(num,Score,name,n,m);
    printf("����\t����\tѧ��\t");
     while(k<m)
    {
        printf("�γ�%d\t",k+1);
        k++;
    }printf("\n");
    for(i=n-1;i>=0;i--)
    {
        printf("%d\t%s\t%ld\t",i+1,name[i],num[i]);
        for(k=0;k<m;k++)
        {
            sum[i]=Score[i][k]+sum[i];
            printf("%d\t",Score[i][k]);
        }
        printf("�ܷ֣�%d\n",sum[i]);
    }
    printf("\n");
}

void SortinNum(long num[],int Score[][M],char name[][MAX_LINE],int n,int m)
{
    int i,j,k=0;char temp[MAX_LINE];int sum[N]={0};
    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(num[i]>num[j])
            {
            strcpy(temp,name[i]);
            strcpy(name[i],name[j]);
            strcpy(name[j],temp);
            for(k=0;k<m;k++)
            {Swap(&Score[j][k],&Score[i][k]);}
            Swap2(&num[j],&num[i]);
            }
        }
    }
     printf("ѧ��\t����\t");
     for(k=0;k<m;k++)
     {
        printf("�γ�%d\t",k+1);
     }
    printf("\n");
     for(i=0;i<n;i++)
     {
        printf("%ld\t%s\t",num[i],name[i]);
         for(k=0;k<m;k++)
        {
            sum[i]=Score[i][k]+sum[i];
            printf("%d\t",Score[i][k]);
        }
        printf("�ܷ֣�%d\n",sum[i]);
     }
    printf("\n");
}



void SortinName(long num[],int Score[][M],char name[][MAX_LINE],int n,int m)
{
      int i,k=0;int sum[N]={0};
	 Datasort_by_name(num,Score,name,n,m);
     printf("ѧ��\t����\t");
      while(k<m)
    {
        printf("�γ�%d\t",k+1);
        k++;
    }printf("\n");
     for(i=0;i<n;i++)
     {
        printf("%ld\t%s\t",num[i],name[i]);
         for(k=0;k<m;k++)
        {
            sum[i]=Score[i][k]+sum[i];
            printf("%d\t",Score[i][k]);
        }
        printf("�ܷ֣�%d\n",sum[i]);
     }
    printf("\n");
}

void Search_by_Num(long num[],int Score[][M],char name[][MAX_LINE],int n,int m)
{
    int i,k;
    int flag=1;
    long number;
    int sum=0;
    char temp[MAX_LINE];
    printf("Please input the number:");
    scanf("%ld",&number);
    Datasort(num,Score,name,n,m);
    for(i=0;i<n;i++)
    {
        if(num[i]==number)
        {
            strcpy(temp,name[i]);
            flag=0;
            break;
        }
    }
   if(flag==1)
    {
        printf("Not found!\n");

    }
    else
    {
    printf("���� %s  ���� %d  ѧ�� %ld ",temp,i+1,number);
    for(k=0;k<m;k++)
    {
        printf("subject%d :%d\t",k+1,Score[i][k]);
        sum+=Score[i][k];
    }
    printf("�ܷ�:%d\n",sum);
   }
}

void Search_by_Name(long num[],int Score[][M],char name[][MAX_LINE],int n,int m)
{

    int i,k,sum=0;int flag=1;long number;char temp[MAX_LINE];
    printf("Please input the name for researching:");
    scanf("%s",temp);
    for(i=0;i<n;i++)
    {
        if(strcmp(name[i],temp)==0)
        {
            number=num[i];
            flag=0;
            break;
        }
    }
        if(flag==1)
    {
        printf("Not found!\n");

    }
    else
    {
    printf("���� %s ���� %d ѧ�� %ld\t",temp,i+1,number);
    for(k=0;k<m;k++)
    {
        printf("subject%d:%d\t",k+1,Score[i][k]);
        sum+=Score[i][k];
    }
    printf("�ܷ�:%d\n",sum);
    printf("\n");
	}
}


void Stana(int Score[][M],int n,int m)
{
    int i,j;
    int count[5][M]={0};
    for(j=0;j<m;j++)
    {
    for(i=0;i<n;i++)
    {
        if(Score[i][j]>=90&&Score[i][j]<=100)
        {
            count[0][j]++;
        }
        else if(Score[i][j]>=80&&Score[i][j]<=89)
        {
            count[1][j]++;
        }
        else if(Score[i][j]>=70&&Score[i][j]<=79)
        {
            count[2][j]++;
        }
        else if(Score[i][j]>=60&&Score[i][j]<=69)
        {
            count[3][j]++;
        }
        else if(Score[i][j]>=0&&Score[i][j]<=59)
        {
            count[4][j]++;
        }
    }
    printf("couse %d��������Ϊ %d,ռ %f%%\n",j+1,count[0][j],100*(float)count[0][j]/n);
    printf("couse %d��������Ϊ %d,ռ %f%%\n",j+1,count[1][j],100*(float)count[1][j]/n);
    printf("couse %d�е�����Ϊ %d,ռ %f%%\n",j+1,count[2][j],100*(float)count[2][j]/n);
    printf("couse %d��������Ϊ %d,ռ %f%%\n",j+1,count[3][j],100*(float)count[3][j]/n);
    printf("couse %d����������Ϊ %d,ռ %f%%\n",j+1,count[4][j],100*(float)count[4][j]/n);
    printf("\n");
    }
}

