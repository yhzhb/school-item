#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define N 30
#define M 6
typedef struct student
{
    long number;
    char studentName[10];
    int score[6];
}STUDENT;
void Inputrecord(STUDENT stu[],int n,int m);
void Calculate_by_Course(STUDENT stu[],int sum_course[],float aver_course[],int n,int m);
void Calculate_stu(STUDENT stu[],int sum_stu[],float aver_stu[],int n,int m);
void Datasort(STUDENT stu[],int n,int m,int sum_stu[]);
void Search_by_Num(STUDENT stu[],int n,int m,int sum_stu[]);
void Search_by_Name(STUDENT stu[],int n,int m,int sum_stu[]);
void SortscoreD(STUDENT stu[],int n,int m,int sum_stu[]);
void SortscoreA(STUDENT stu[],int n,int m,int sum_stu[]);
void SortinNum(STUDENT stu[],int n,int m,int sum_stu[]);
void SortinName(STUDENT stu[],int n,int m,int sum_stu[]);
void Stana(STUDENT stu[],int n,int m);
void WritetoFile(STUDENT stu[],int n ,int m,int sum_stu[],float aver_stu[]);
void ReadfromFile(STUDENT stu[],int *n,int *m,int sum_stu[],float aver_stu[]);
int main()
{
    int count=0,n,m,choice=0;
    int sum_stu[N];int sum_course[M];float aver_course[M],aver_stu[N];
    STUDENT stu[N];
    do
   {
    printf("������ѧ���������Ϳγ�����");
    scanf("%d%d",&n,&m);
    }while(n<=0||m>6||n>30||m<=0);
    printf("1.Input record\n2.Calculate total and average score of every course\n3.Calculate total and average score of every student\n");
    printf("4.Sort in descending order by total score of every student\n5.Sort in ascending order by total score of every student\n6.Sort in ascending order by number\n7.Sort in dictionary order by name\n");
    printf("8.Search by number\n9.Search by name\n10.Statistic analysis\n11.List record\n12.Write to a file\n13.Read from a file\n0.Exit\n");
    do
{
    printf("Please enter your choice:");
    scanf("%d",&choice);
    count++;
    if(count==1&&choice!=1&&choice!=0&&choice!=13)
    {
    	    printf("You haven't input record !\n");
            printf("Please input record.\n\n");
            choice=1;
	}
	while(count!=1&&choice>13)
    {
      printf("Wrong!Please enter your choice:");
      scanf("%d",&choice);
    }
    switch(choice)
    {
        case 1:Inputrecord(stu,n,m);break;
        case 2:Calculate_by_Course(stu,sum_course,aver_course,n,m);break;
        case 3:Calculate_stu(stu,sum_stu,aver_stu,n,m);
        for(int k=0;k<n;k++){printf("student %s  :Total %d    Average %.2f\n",stu[k].studentName,sum_stu[k],aver_stu[k]);}printf("\n");break;
        case 4:Calculate_stu(stu,sum_stu,aver_stu,n,m);SortscoreD(stu,n,m,sum_stu);break;
        case 5:Calculate_stu(stu,sum_stu,aver_stu,n,m);SortscoreA(stu,n,m,sum_stu);break;
        case 6:SortinNum(stu,n,m,sum_stu);break;
        case 7:SortinName(stu,n,m,sum_stu);break;
        case 8:Datasort(stu,n,m,sum_stu);Search_by_Num(stu,n,m,sum_stu);break;
        case 9:Datasort(stu,n,m,sum_stu);Search_by_Name(stu,n,m,sum_stu);break;
        case 10:Stana(stu,n,m);break;
        case 11:Calculate_stu(stu,sum_stu,aver_stu,n,m);SortinNum(stu,n,m,sum_stu);Calculate_by_Course(stu,sum_course,aver_course,n,m);break;
        case 12:Datasort(stu,n,m,sum_stu);Calculate_stu(stu,sum_stu,aver_stu,n,m);WritetoFile(stu,n ,m,sum_stu,aver_stu);break;
        case 13:ReadfromFile(stu,&n,&m,sum_stu,aver_stu);Calculate_stu(stu,sum_stu,aver_stu,n,m);SortinNum(stu,n,m,sum_stu);break;
        case 0:return 0;
    }
}while(choice>0&&choice<=13);

}


void Inputrecord(STUDENT stu[],int n ,int m)
{
    int i,j;

    for(i=0;i<n;i++)
    {
        printf("Please input the student's ID and name:");
        scanf("%ld",&stu[i].number);
        scanf("%s",stu[i].studentName);
        for(j=0;j<m;j++)
        {
            printf("Please input the student's score of subject %d:",j+1);
            scanf("%d",&stu[i].score[j]);
                while(stu[i].score[j]>100||stu[i].score[j]<0)
             {
                 printf("Wrong!Please input the student's score of subject %d again:",j+1);
                 scanf("%d",&stu[i].score[j]);
             }
        }
    }
}

void Calculate_by_Course(STUDENT stu[],int sum_course[],float aver_course[],int n,int m)
{
    int i,j,k,temp;
    for(i=0;i<m;i++)
    {
        temp=0;
        for(j=0;j<n;j++)
        {
            temp+=stu[j].score[i];

        }
        sum_course[i]=temp;
        aver_course[i]=(float)sum_course[i]/n;
    }
    for(k=0;k<m;k++)
    {
        printf("course %d  :Total %d    Average %.2f\n",k+1,sum_course[k],aver_course[k]);
    }
    printf("\n");
}

void Calculate_stu(STUDENT stu[],int sum_stu[],float aver_stu[],int n,int m)
{
    int i,j,temp;
    for(i=0;i<n;i++)
    {
        temp=0;
        for(j=0;j<m;j++)
        {
            temp+=stu[i].score[j];
        }
        sum_stu[i]=temp;
        aver_stu[i]=(float)sum_stu[i]/m;
    }

}


void Swap(int*x,int*y)
{
    int temp;
    temp=*x;
    *x=*y;
    *y=temp;
}


void Datasort(STUDENT stu[],int n,int m,int sum_stu[])
{
    int i,j;STUDENT temp;STUDENT temp2;
    for(i=0;i<n-1;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(sum_stu[j]>sum_stu[i])
            {
                temp=stu[i];temp2=stu[j];stu[j]=temp;stu[i]=temp2;
                Swap(&sum_stu[j],&sum_stu[i]);
            }
            else if(sum_stu[j]==sum_stu[i]&&stu[j].number<stu[i].number)
            {
                temp=stu[i];temp2=stu[j];stu[j]=temp;stu[i]=temp2;
            }
        }
    }

}

void SortscoreD(STUDENT stu[],int n,int m,int sum_stu[])
{
    int i,j,k=0;
    Datasort(stu,n,m,sum_stu);
    printf("����\t����\tѧ��\t");
    while(k<m)
    {
        printf("�γ�%d\t",k+1);
        k++;
    }
    printf("�ܷ�\n");
    for(i=0;i<n;i++)
     {
        printf("%d\t%s\t%ld\t",i+1,stu[i].studentName,stu[i].number);
        for(j=0;j<m;j++)
        {
            printf("%d\t",stu[i].score[j]);
        }
        printf("%d\n",sum_stu[i]);
     }
     printf("\n");
}

void SortscoreA(STUDENT stu[],int n,int m,int sum_stu[])
{
    int i,j,k=0;
    Datasort(stu,n,m,sum_stu);
    printf("����\t����\tѧ��\t");
    while(k<m)
    {
        printf("�γ�%d\t",k+1);
        k++;
    }
    printf("�ܷ�\n");
    for(i=n-1;i>=0;i--)
     {
        printf("%d\t%s\t%ld\t",i+1,stu[i].studentName,stu[i].number);
        for(j=0;j<m;j++)
        {
            printf("%d\t",stu[i].score[j]);
        }
        printf("%d\n",sum_stu[i]);
     }
     printf("\n");
}

void SortinNum(STUDENT stu[],int n,int m,int sum_stu[])
{
    int i,j,k=0;
    STUDENT temp;STUDENT temp2;
    for(i=0;i<n-1;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(stu[j].number<stu[i].number)
            {
                temp=stu[i];temp2=stu[j];stu[j]=temp;stu[i]=temp2;
                Swap(&sum_stu[j],&sum_stu[i]);
            }
        }
    }
    printf("����\t����\tѧ��\t");
    while(k<m)
    {
        printf("�γ�%d\t",k+1);
        k++;
    }
    printf("�ܷ�\n");
    for(i=0;i<n;i++)
     {
        printf("%d\t%s\t%ld\t",i+1,stu[i].studentName,stu[i].number);
        for(j=0;j<m;j++)
        {
            printf("%d\t",stu[i].score[j]);
        }
        printf("%d\n",sum_stu[i]);
     }
     printf("\n");
}

void SortinName(STUDENT stu[],int n,int m,int sum_stu[])
{
    int i,j,k=0;
    STUDENT temp;STUDENT temp2;
    for(i=0;i<n-1;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(strcmp(stu[j].studentName,stu[i].studentName)<0)
            {
                temp=stu[i];temp2=stu[j];stu[j]=temp;stu[i]=temp2;
                Swap(&sum_stu[j],&sum_stu[i]);
            }
        }
    }
    printf("����\t����\tѧ��\t");
    while(k<m)
    {
        printf("�γ�%d\t",k+1);
        k++;
    }
    printf("�ܷ�\n");
    for(i=0;i<n;i++)
     {
        printf("%d\t%s\t%ld\t",i+1,stu[i].studentName,stu[i].number);
        for(j=0;j<m;j++)
        {
            printf("%d\t",stu[i].score[j]);
        }
        printf("%d\n",sum_stu[i]);
     }
     printf("\n");
}

void Search_by_Num(STUDENT stu[],int n,int m,int sum_stu[])
{
    long num;
    printf("Please input the number for researching:\n");
    scanf("%ld",&num);
    int i,k,flag=1;
    for(i=0;i<n;i++)
    {
        if(stu[i].number==num)
          {
            flag=0;
           break;
          }
    }
    if(flag==1)
    {
        printf("not find!\n");
    }
   else
   {
       printf("���� %s\t���� %d\tѧ�� %ld\t",stu[i].studentName,i+1,stu[i].number);
       for(k=0;k<m;k++)
    {
        printf("subject%d  :%d\t",k+1,stu[i].score[k]);
    }
    printf("�ܷ�:%d\n",sum_stu[i]);
   }
}

void Search_by_Name(STUDENT stu[],int n,int m,int sum_stu[])
{
    char temp[10];int i,k;int flag=1;
    printf("Please input the name for researching:");
    scanf("%s",temp);
    for(i=0;i<n;i++)
    {
        if(strcmp(stu[i].studentName,temp)==0)
        {
            flag=0;
            break;
        }
    }
        if(flag==1)
    {
        printf("Not found!\n");
    }
    else
    {
    printf("���� %s���� %d,ѧ�� %ld\t",temp,i+1,stu[i].number);
    for(k=0;k<m;k++)
    {
        printf("subject%d :%d\t",k+1,stu[i].score[k]);
    }
    printf("�ܷ�:%d\n",sum_stu[i]);
    printf("\n");
	}
}


void Stana(STUDENT stu[],int n,int m)
{
    int i,j;
    int count[5][M]={0};
    for(j=0;j<m;j++)
    {
    for(i=0;i<n;i++)
    {
        if(stu[i].score[j]>=90&&stu[i].score[j]<=100)
        {
            count[0][j]++;
        }
        else if(stu[i].score[j]>=80&&stu[i].score[j]<=89)
        {
            count[1][j]++;
        }
        else if(stu[i].score[j]>=70&&stu[i].score[j]<=79)
        {
            count[2][j]++;
        }
        else if(stu[i].score[j]>=60&&stu[i].score[j]<=69)
        {
            count[3][j]++;
        }
        else if(stu[i].score[j]>=0&&stu[i].score[j]<=59)
        {
            count[4][j]++;
        }
    }
    printf("couse %d��������Ϊ %d,ռ %f%%\n",j+1,count[0][j],100*(float)count[0][j]/n);
    printf("couse %d��������Ϊ %d,ռ %f%%\n",j+1,count[1][j],100*(float)count[1][j]/n);
    printf("couse %d�е�����Ϊ %d,ռ %f%%\r\n",j+1,count[3][j],100*(float)count[3][j]/n);
    printf("couse %d����������Ϊ %d,ռ %f%%\n",j+1,count[4][j],100*(float)count[4][j]/n);
    printf("\n");
    }
}

void WritetoFile(STUDENT stu[],int n ,int m,int sum_stu[],float aver_stu[])
{
    FILE *fp;
    int i,j,k=0;
    if((fp = fopen("experiment_9.txt","w"))==NULL)
    {
        printf("Failure to open experiment_9.txt!\n");
        exit(0);
    }
     fprintf(fp,"����%d\t��Ŀ��%d\n\n",n,m);
     fprintf(fp,"����\t����\tѧ��\t");
    while(k<m)
    {
        fprintf(fp,"�γ�%d\t",k+1);
        k++;
    }
    fprintf(fp,"�ܷ�\t����\n");
    for(i=0;i<n;i++)
    {
        fprintf(fp,"%d\t%s\t%ld\t",i+1,stu[i].studentName,stu[i].number);
        for(j=0;j<m;j++)
        {
            fprintf(fp,"%6d\t",stu[i].score[j]);
        }
        fprintf(fp,"%4d\t%8f\n",sum_stu[i],aver_stu[i]);
    }
    fclose(fp);
}

void ReadfromFile(STUDENT stu[],int *n,int *m,int sum_stu[],float aver_stu[])
{
    FILE *fp;
    int i,j;
    if((fp=fopen("experiment9.txt","r"))==NULL)
    {
        printf("Failure to open experiment9.txt!\n");
        exit(0);
    }
    for(i=0;i<*n;i++)
    {
        fscanf(fp,"%ld\t%s",&stu[i].number,stu[i].studentName);
        for(j=0;j<*m;j++)
        {
            fscanf(fp,"%6d\t",&stu[i].score[j]);
        }
    }
    fclose(fp);
}
