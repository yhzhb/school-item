#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fs.h"
// ls.c(文件路径名处理) grep.c(匹配)
//仿照grep正则匹配的匹配算法，也可以自己写一个简单O(n^2)的字串匹配算法

char buf[1024];
int match(char*, char*);
int matchhere(char*, char*);
int matchstar(int, char*, char*);

int
match(char *re, char *text)
{
  if(re[0] == '^')
    return matchhere(re+1, text);
  do{  // must look at empty string
    if(matchhere(re, text))
      return 1;
  }while(*text++ != '\0');
  return 0;
}

// matchhere: search for re at beginning of text
int matchhere(char *re, char *text)
{
  if(re[0] == '\0')
    return 1;
  if(re[1] == '*')
    return matchstar(re[0], re+2, text);
  if(re[0] == '$' && re[1] == '\0')
    return *text == '\0';
  if(*text!='\0' && (re[0]=='.' || re[0]==*text))
    return matchhere(re+1, text+1);
  return 0;
}

// matchstar: search for c*re at beginning of text
int matchstar(int c, char *re, char *text)
{
  do{  // a * matches zero or more instances
    if(matchhere(re, text))
      return 1;
  }while(*text!='\0' && (*text++==c || c=='.'));
  return 0;
}

int blank(char *buf){//获得buf中除去空格的字符数量
  int i = 0; 
  char *p;
  for(p = buf;*p!=' ';p++){
    i++;
  }
  return i;
}

//ls中的函数做部分修改
char*
fmtname(char *path)
{//路径格式化为文件名(除去斜杠)
  static char buf[DIRSIZ+1];
  char *p;

  // Find first character after last slash.除斜杠
  for(p=path+strlen(path); p >= path && *p != '/'; p--)
    ;
  p++;

  // Return blank-padded name.（取得文件名）
  if(strlen(p) >= DIRSIZ)
    return p;
 // memset(buf,'\0',sizeof(buf)); 
  memmove(buf, p, strlen(p));
  //printf("233.%d,%s\n",strlen(buf),buf);
  memset(buf+strlen(p), ' ', DIRSIZ-strlen(p));//空白填充斜杠
  //printf("344.%d,%s\n",blank(buf),buf);
  //memmove(p,p+DIRSIZ)
  //buf = p;
  return buf;
}





void find(char *dir,char *file){//查找功能函数，同样来自ls部分更改
    char buf[512], *p;//定义buf, p指针
  
    int fl;//定义文件描述符

    //数据类型的结构体
    struct dirent de;//描述文件名称
    struct stat st;//描述文件信息,判断是否为目录
   

    // open() 函数打开路径，并判断出错。试探进入给定的路径

  if((fl = open(dir, 0)) < 0){
    fprintf(2, "ls: cannot open %s\n", dir);
    return;
  }

  //由文件描述符取得文件的状态,没有文件的具体信息则报错
  if(fstat(fl, &st) < 0){
    fprintf(2, "ls: cannot stat %s\n", dir);
    close(fl);
    return;
  }


  switch(st.type){
  case T_FILE:     //是给定目录下的文件，比对成功可以直接输出其绝对路径
    if(match(file,fmtname(dir)) && (strlen(file)==blank(fmtname(dir)))){//将正则匹配转化为相等，判断字符串长度
     // printf("%d,%d,%s\n",strlen(file),strlen(fmtname(dir)),fmtname(dir));
      printf("%s\n",dir);
    }
    //printf("%s %d %d %l\n", fmtname(path), st.type, st.ino, st.size);
    break;

// 读取子目录下文件信息
  case T_DIR:
    if(strlen(dir) + 1 + DIRSIZ + 1 > sizeof(buf)){ //文件名长度+路径长度  >  buf长度，则报错
      printf("ls: path too long\n");
      break;
    }
    strcpy(buf, dir);//首先将dir绝对路径先读到buf中，例如buf = './home/hang'
    p = buf+strlen(buf);
    *p++ = '/';
    //读取 fl ，如果 read 返回字节数与 de 长度相等则循环
    while(read(fl, &de, sizeof(de)) == sizeof(de)){
      if(de.inum == 0)
        continue;
    // 不要递归 "." 和 ".."
     if (!strcmp(de.name, ".") || !strcmp(de.name, ".."))
          {continue;}
      memmove(p, de.name, DIRSIZ);
      p[DIRSIZ] = 0;
      if(stat(buf, &st) < 0){
        printf("ls: cannot stat %s\n", buf);
        continue;
      }

      find(buf,file);//目录继续递归寻找
      //printf("%s %d %d %d\n", fmtname(buf), st.type, st.ino, st.size);
    }
    break;
  }
  close(fl);

}

int main(int argc,char* argv[]){
    if(argc!=3){
        printf("请检查参数数量是否正确!\n"); //检查参数数量是否正确
        exit(-1);
    }
find(argv[1],argv[2]);
exit(0);
}



