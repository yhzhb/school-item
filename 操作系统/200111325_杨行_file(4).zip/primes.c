#include "kernel/types.h"
#include "user/user.h"
#include <stddef.h>

void Find_Prime(int *fd){//读取打印
    int i;
    close(fd[1]);
    if(read(fd[0],&i,sizeof(int))){
        printf("prime %d\n",i);//管道的首数值必定为素数，直接打印
        int New_fd[2];
        pipe(New_fd);

        int pid = fork();
        if(pid == -1){
            printf("fork error!");
            exit(-1);
        }else if(pid > 0){//每次新建时负责写入的父进程
           close(New_fd[0]);//关闭新管道读(管道的关闭一定要注意，否则会出现MISSING '^OK$'（管道阻塞）unexpected scause（内存不足）)
           int choose;
           while(read(fd[0],&choose,sizeof(int))){
               if(choose % i != 0){//体现筛法，符合条件继续写入管道
                 write(New_fd[1],&choose,sizeof(int));
               }
           }
           close(fd[0]);//读完，关闭旧管道读
           close(New_fd[1]);//写完，关闭新管道写
           wait(NULL);//等待子进程
        }else{
            Find_Prime(New_fd);
        }
    }

} 


int main(int argc,char* argv[]){
int fd[2];
pipe(fd);

  int pid = fork();
  if(pid == -1){
    printf("fork error!");
    exit(-1);
   }else if(pid > 0){//parent process,第一个主进程
     close(fd[0]);
     for(int i=2;i<=35;i++){
        write(fd[1],&i,sizeof(int));//第二个是缓冲区首地址
     }
     close(fd[1]);
     wait(NULL);//等待子进程

   }else if(pid == 0){//child process
      Find_Prime(fd);
   }
   exit(0);
}
