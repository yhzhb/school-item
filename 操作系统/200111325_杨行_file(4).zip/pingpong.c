#include "kernel/types.h"
#include "user/user.h"
#include <stddef.h>

int main(int argc,char* argv[]){
   int ping_fd[2],pong_fd[2];
   int pipe_1 = pipe(ping_fd);
   int pipe_2 = pipe(pong_fd);

   if(pipe_1==-1 || pipe_2 ==-1){
    printf("pipe error!");
    exit(-1);
   }

   int pid = fork();
   
   if(pid == -1){
    printf("fork error!");
    exit(-1);
   }else if(pid == 0){//child process

     char buf[16];
     close(pong_fd[0]);
     close(ping_fd[1]);
     read(ping_fd[0],buf,sizeof(buf));
     printf("%d: %s\n",getpid(),buf);//注意冒号与字符之间有一个空格。不然会错。
     write(pong_fd[1],"received pong",strlen("received pong"));
     close(ping_fd[0]);
     close(pong_fd[1]);
   }else if(pid > 0){//parent
     char buf[16];
     //关闭管道中不使用的端
     close(ping_fd[0]);
     close(pong_fd[1]);
     write(ping_fd[1],"received ping",strlen("received ping"));
     wait(NULL);//使父进程等待防止出现僵尸进程。
     read(pong_fd[0],buf,sizeof(buf));
     printf("%d: %s\n",getpid(),buf);
     close(pong_fd[0]);
     close(ping_fd[1]);
   }
  
   
exit(0);
}




