#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/param.h"


int main(int argc, char *argv[])
{
   int argvs_num =0;//计数器读到第几个参数
   //char *command = "echo";//默认值
   // 提示d
   char * argvs[MAXARG];//exec运行指令时的新参数列
   
     if(argc<2){
        printf("参数过少\n");
            exit(1);
     }


     if (argc + 1 > MAXARG) {
            printf("参数过多\n");
            exit(1);
        }
    for(int i= 1; i<argc ;i++){
            argvs[argvs_num] = argv[i];//i从1开始越过xargs
            argvs_num++;
    }

   
   while(1){
    int i =0;
    char buf[MAXARG]={'\0'};
    char temp[MAXARG] ={'\0'};//全部清空归零
    int read_flag;
    while((read_flag = read(0,&buf[i],1))>0){
        if(buf[i]=='\n'){
            break;
        }else{
        temp[i]=buf[i];
        i++;
       }
   }

    if(read_flag<=0 ){
        break;
    }
 
 //子线程执行命令

            argvs[argvs_num] = temp;
            if (fork() == 0) {
                     exec(argvs[0], argvs);
                    }
                // 等待子线程执行完毕
                   else{ 
                      wait(0);
            }

                
   }
  
    exit(0);
}

