// Buffer cache.
//
// The buffer cache is a linked list of buf structures holding
// cached copies of disk block contents.  Caching disk blocks
// in memory reduces the number of disk reads and also provides
// a synchronization point for disk blocks used by multiple processes.
//
// Interface:
// * To get a buffer for a particular disk block, call bread.
// * After changing buffer data, call bwrite to write it to disk.
// * When done with the buffer, call brelse.
// * Do not use the buffer after calling brelse.
// * Only one process at a time can use a buffer,
//     so do not keep them longer than necessary.


#include "types.h"
#include "param.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "riscv.h"
#include "defs.h"
#include "fs.h"
#include "buf.h"
#define NBUCKETS 13

struct {
  struct spinlock lock[NBUCKETS];
  struct buf buf[NBUF];

  // Linked list of all buffers, through prev/next.
  // Sorted by how recently the buffer was used.
  // head.next is most recent, head.prev is least.
  struct buf hashbucket[NBUCKETS]; //每个哈希队列一个linked list及一个lock
} bcache;


int hash(uint x){//哈希函数，通过块来找到桶
  return x % NBUCKETS;
}

/*初始化锁的函数，同样对每个都加锁,同时对*/

void
binit(void)
{
  struct buf *b;

  for(int i=0;i<NBUCKETS;i++){// 初始化hash桶的锁
  char lock_name[8];
  snprintf(lock_name,sizeof(lock_name),"bcache_%d",i);
  initlock(&bcache.lock[i], lock_name);//每个桶的锁

  // Create linked list of each_buffers_hashlist
  bcache.hashbucket[i].prev = &bcache.hashbucket[i];
  bcache.hashbucket[i].next = &bcache.hashbucket[i];
  
  }

  //缓存分配，由于可以窃取，考虑初始时直接将块全部分给第一个桶
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    b->next = bcache.hashbucket[0].next;
    b->prev = &bcache.hashbucket[0];
    initsleeplock(&b->lock, "buffer");
    bcache.hashbucket[0].next->prev = b;
    bcache.hashbucket[0].next = b;
  }
}

// Look through buffer cache for block on device dev.
// If not found, allocate a buffer.
// In either case, return locked buffer.
//函数的作用是在双向链表中找到对应设备 dev 和块号 blockno 的缓存块, 引用计数加 1 进行返回
static struct buf*
bget(uint dev, uint blockno)
{
  struct buf *b;
  uint mintime;
  int  id = hash(blockno);//通过哈希函数分配 
  acquire(&bcache.lock[id]);

  // Is the block already cached?
  //首先根据 blockno 在相应 hashbucket 的链表中寻找对应的缓存块,找到直接返回
  for(b = bcache.hashbucket[id].next; b != &bcache.hashbucket[id]; b = b->next){
    if(b->dev == dev && b->blockno == blockno){
      b->refcnt++;
      release(&bcache.lock[id]);
      acquiresleep(&b->lock);
      return b;
    }
  }

  // Not cached.
  // 首先尝试在自己的hash桶中根据时间戳找寻缓存块
  mintime = -1;//时间设为最大即0xfffff
  struct buf *minbuf = 0;//缓冲temp
  for(b = bcache.hashbucket[id].prev; b != &bcache.hashbucket[id]; b = b->prev){
     
   if(b->refcnt == 0 && b-> time < mintime) {
     mintime = b->time;
      minbuf =  b;
      }
    }
    if(minbuf){
      //只需赋值
      minbuf->dev = dev;
      minbuf->blockno = blockno;
      minbuf->valid = 0;
      minbuf->refcnt = 1;
      release(&bcache.lock[id]);
      acquiresleep(&minbuf->lock);
      return minbuf;
    }

  //其他的哈希桶
  // 通过
  for(int i = hash(id+1);i!=id;i=hash(i+1)){
      mintime = -1;//即0xfffff
      struct buf *minbuf = 0;
      acquire(&bcache.lock[i]);
    for(b = bcache.hashbucket[i].prev; b != &bcache.hashbucket[i]; b = b->prev){
     
   if(b->refcnt == 0 && b-> time < mintime) {
      mintime = b->time;
      minbuf =  b;
      }
    }
  
    if(minbuf){
      //赋值
       minbuf->dev = dev;
      minbuf->blockno = blockno;
      minbuf->valid = 0;
      minbuf->refcnt = 1;
      
      //移除出原来的hash桶
      minbuf->next->prev = minbuf->prev;
      minbuf->prev->next = minbuf->next;
      //加入现在的hash表
      minbuf->next = bcache.hashbucket[id].next;
      minbuf->prev = &bcache.hashbucket[id];
      bcache.hashbucket[id].next->prev = minbuf;
      bcache.hashbucket[id].next = minbuf;
      //解锁操作
      release(&bcache.lock[i]);
      release(&bcache.lock[id]);
      acquiresleep(&minbuf->lock);
      return minbuf;
    }
    release(&bcache.lock[i]);
   

  }  
  release(&bcache.lock[id]);
  panic("bget: no buffers");
}


// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
  if(!holdingsleep(&b->lock))
    panic("bwrite");
  virtio_disk_rw(b, 1);
}

// Release a locked buffer.
// Move to the head of the most-recently-used list.
//锁改为缓存块对应在的桶的锁
void
brelse(struct buf *b)
{
  if(!holdingsleep(&b->lock))
    panic("brelse");

  releasesleep(&b->lock);

  int id =hash(b-> blockno);//cache块根据硬盘号blockno分配到桶中
  acquire(&bcache.lock[id]);
  b->refcnt--;
  if (b->refcnt == 0) {
    // no one is waiting for it.
    //原来的操作：引用计数为 0, 移至双向链表表头, 使得双向链表表头是最近使用的, 表尾是最近未使用的(LUR原则)
    //b->next->prev = b->prev;
    //b->prev->next = b->next;
    //b->next = bcache.head.next;
    //b->prev = &bcache.head;
    //bcache.head.next->prev = b;
    //bcache.head.next = b;
    //现在：时间戳实现
    b -> time = ticks;

  }
  
  release(&bcache.lock[id]);
}

void
bpin(struct buf *b) {
  int id = hash(b->blockno);
  acquire(&bcache.lock[id]);
  b->refcnt++;
  release(&bcache.lock[id]);
}

void
bunpin(struct buf *b) {
  int id = hash(b->blockno);
  acquire(&bcache.lock[id]);
  b->refcnt--;
  release(&bcache.lock[id]);
}


