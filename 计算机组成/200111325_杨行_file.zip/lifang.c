#include <stdio.h>
#include <stdlib.h>
int Cheng(unsigned x,int y){
int temp=y;
int sum=0;
while(x){
    if(x&1){
        sum=sum+temp;
    }
    x=x>>1;
    temp=temp<<1;
  }
  return sum;
}

int main()
{
  unsigned char x =25;
  long  pingfang= Cheng(x,x);
  long  lifang= Cheng(x,pingfang);
   printf("%d\n",lifang);

}
